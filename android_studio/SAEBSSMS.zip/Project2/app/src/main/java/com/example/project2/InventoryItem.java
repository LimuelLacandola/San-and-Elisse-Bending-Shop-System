package com.example.project2;

public class InventoryItem {
    private String productName;
    private int quantity;
    private int price;
    private String imageUrl;  // Add imageUrl attribute

    public InventoryItem(String productName, int quantity, int price, String imageUrl) {
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
        this.imageUrl = imageUrl;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPrice() {
        return price;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
