package com.example.project2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class SessionsAdapter extends RecyclerView.Adapter<SessionsAdapter.ViewHolder> {

    private List<SessionsItem> dataItemList;

    public SessionsAdapter(List<SessionsItem> dataItemList) {
        this.dataItemList = dataItemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sessions, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        SessionsItem dataItem = dataItemList.get(position);

        holder.usernameTextView.setText("Username: " + dataItem.getUsername());
        holder.fullnameTextView.setText("Full Name: " + dataItem.getFullname());
        holder.loginTimeTextView.setText("Login Time: " + dataItem.getLoginTime());
        holder.logoutTimeTextView.setText("Logout Time: " + dataItem.getLogoutTime());
        holder.timeSpentTextView.setText("Time Spent: " + dataItem.getTimeSpent());
    }

    @Override
    public int getItemCount() {
        return dataItemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView usernameTextView;
        public TextView fullnameTextView;
        public TextView loginTimeTextView;
        public TextView logoutTimeTextView;
        public TextView timeSpentTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            usernameTextView = itemView.findViewById(R.id.usernameTextView);
            fullnameTextView = itemView.findViewById(R.id.fullnameTextView);
            loginTimeTextView = itemView.findViewById(R.id.loginTimeTextView);
            logoutTimeTextView = itemView.findViewById(R.id.logoutTimeTextView);
            timeSpentTextView = itemView.findViewById(R.id.timeSpentTextView);
        }
    }

}
