package com.example.project2;

import android.content.Context;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.eazegraph.lib.charts.BarChart;
import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.BarModel;
import org.eazegraph.lib.models.PieModel;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MainActivity6 extends AppCompatActivity {

    TextView tvCategory1, tvCategory2, tvCategory3;
    TextView tvProduct1, tvProduct2, tvProduct3;
    TextView salesTodayTv, transactionTodayTv, productsTv, mostSoldTv;
    PieChart pieChart;

    private static final int UPDATE_INTERVAL = 2000; // Update every 10 seconds
    private Handler handler = new Handler();

    private Runnable updateSalesAndTransactionRunnable = new Runnable() {
        @Override
        public void run() {
            new FetchTotalSalesTodayAsyncTask().execute();
            new FetchTotalTransactionTodayAsyncTask().execute();
            new FetchNumberofProductsAsyncTask().execute();
            new FetchMostSoldProductAsyncTask().execute();
            handler.postDelayed(this, UPDATE_INTERVAL);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);

        tvCategory1 = findViewById(R.id.tvCategory1);
        tvCategory2 = findViewById(R.id.tvCategory2);
        tvCategory3 = findViewById(R.id.tvCategory3);
        tvProduct1 = findViewById(R.id.tvProduct1);
        tvProduct2 = findViewById(R.id.tvProduct2);
        tvProduct3 = findViewById(R.id.tvProduct3);
        pieChart = findViewById(R.id.piechart);
        salesTodayTv = findViewById(R.id.salesTodayTv);
        transactionTodayTv = findViewById(R.id.transactionTodayTv);
        productsTv = findViewById(R.id.productsTv);
        mostSoldTv = findViewById(R.id.mostSoldTv);

        // Call AsyncTask to fetch most sold products data
        new FetchDataAsyncTask(this).execute();

        // Call AsyncTask to fetch monthly transaction data
        new FetchMonthlyDataAsyncTask(this).execute();

        // Call AsyncTask to fetch total sales today data
        new FetchTotalSalesTodayAsyncTask().execute();

        // Call AsyncTask to fetch total transaction today data
        new FetchTotalTransactionTodayAsyncTask().execute();

        // Call AsyncTask to fetch total products data
        new FetchNumberofProductsAsyncTask().execute();

        // Call AsyncTask to fetch most sold products data
        new FetchMostSoldProductAsyncTask().execute();

        handler.post(updateSalesAndTransactionRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Stop the periodic update when the activity is destroyed
        handler.removeCallbacks(updateSalesAndTransactionRunnable);
    }

    private static class FetchDataAsyncTask extends AsyncTask<Void, Void, String> {

        private final Context context;
        private final MainActivity6 mainActivity;

        // Constructor to pass the context
        public FetchDataAsyncTask(MainActivity6 activity) {
            this.context = activity;
            this.mainActivity = activity;
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                // Replace "YOUR_PHP_URL" with the actual URL of your PHP file
                URL url = new URL("https://saeb.lightsolus.xyz/fetch_product_category_data.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                // Reading the response
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                reader.close();

                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    // Parse JSON response
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray categoriesArray = jsonObject.getJSONArray("categories");
                    JSONArray categoryCountsArray = jsonObject.getJSONArray("categoryCounts");

                    // Extract data from JSON arrays
                    List<String> categories = new ArrayList<>();
                    List<Integer> categoryCounts = new ArrayList<>();

                    for (int i = 0; i < categoriesArray.length(); i++) {
                        categories.add(categoriesArray.getString(i));
                        categoryCounts.add(categoryCountsArray.getInt(i));
                    }

                    // Retrieve colors from colors.xml
                    int color_one = ContextCompat.getColor(context, R.color.color_one);
                    int color_two = ContextCompat.getColor(context, R.color.color_two);
                    int color_three = ContextCompat.getColor(context, R.color.color_three);

                    // Set data to UI components
                    mainActivity.setData(categories, categoryCounts, color_one, color_two, color_three);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static class FetchMonthlyDataAsyncTask extends AsyncTask<Void, Void, String> {

        private final Context context;
        private final MainActivity6 mainActivity;

        // Constructor to pass the context
        public FetchMonthlyDataAsyncTask(MainActivity6 activity) {
            this.context = activity;
            this.mainActivity = activity;
        }

        @Override
        protected String doInBackground(Void... params) {
            try {
                // Replace "YOUR_PHP_URL" with the actual URL of your fetch_monthly_transaction_data.php file
                URL url = new URL("https://saeb.lightsolus.xyz/fetch_monthly_transaction_data.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                // Reading the response
                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                reader.close();

                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    // Parse JSON response
                    JSONObject jsonObject = new JSONObject(result);
                    JSONArray labelsArray = jsonObject.getJSONArray("labels");
                    JSONArray transactionCountsArray = jsonObject.getJSONArray("transactionCounts");

                    // Extract data from JSON arrays
                    List<String> labels = new ArrayList<>();
                    List<Integer> transactionCounts = new ArrayList<>();

                    for (int i = 0; i < labelsArray.length(); i++) {
                        labels.add(labelsArray.getString(i));
                        transactionCounts.add(transactionCountsArray.getInt(i));
                    }

                    // Define color resources for each month in colors.xml
                    int[] monthColors = new int[]{
                            R.color.january,
                            R.color.february,
                            R.color.march,
                            R.color.april,
                            R.color.may,
                            R.color.june,
                            R.color.july,
                            R.color.august,
                            R.color.september,
                            R.color.october,
                            R.color.november,
                            R.color.december,
                    };

                    // Call the method with the color resources
                    mainActivity.setBarChartData(labels, transactionCounts, monthColors);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    private class FetchTotalSalesTodayAsyncTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {
                URL url = new URL("https://saeb.lightsolus.xyz/android_studio/total_sales_today.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                reader.close();

                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                // Set the fetched data to salesTodayTv TextView
                salesTodayTv.setText(result.trim());
            }
        }
    }

    private class FetchTotalTransactionTodayAsyncTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {
                URL url = new URL("https://saeb.lightsolus.xyz/android_studio/total_transactions_today.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                reader.close();

                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                // Set the fetched data to salesTodayTv TextView
                transactionTodayTv.setText(result.trim());
            }
        }
    }

    private class FetchNumberofProductsAsyncTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {
                URL url = new URL("https://saeb.lightsolus.xyz/android_studio/total_number_of_products.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                reader.close();

                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                // Set the fetched data to salesTodayTv TextView
                productsTv.setText(result.trim());
            }
        }
    }

    private class FetchMostSoldProductAsyncTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... params) {
            try {
                URL url = new URL("https://saeb.lightsolus.xyz/android_studio/most_sold_product.php");
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                BufferedReader reader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line).append("\n");
                }
                reader.close();

                return stringBuilder.toString();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                // Set the fetched data to salesTodayTv TextView
                mostSoldTv.setText(result.trim());
            }
        }
    }


    private void setData(List<String> categories, List<Integer> categoryCounts, int color1, int color2, int color3) {
        // Set data to TextViews
        if (categories.size() >= 1) tvCategory1.setText(categories.get(0));
        if (categories.size() >= 2) tvCategory2.setText(categories.get(1));
        if (categories.size() >= 3) tvCategory3.setText(categories.get(2));

        // Set data to PieChart
        for (int i = 0; i < Math.min(categories.size(), categoryCounts.size()); i++) {
            int color;
            switch (i) {
                case 0:
                    color = color1;
                    break;
                case 1:
                    color = color2;
                    break;
                case 2:
                    color = color3;
                    break;
                default:
                    color = color1;
            }
            pieChart.addPieSlice(new PieModel(categories.get(i), categoryCounts.get(i), color));
        }

        pieChart.startAnimation();

        // Update most sold products based on category data
        updateMostSoldProducts(categories, categoryCounts);
    }

    private void updateMostSoldProducts(List<String> categories, List<Integer> categoryCounts) {
        // Update TextViews based on fetched category data
        if (categories.size() >= 1) {
            tvProduct1.setText(categories.get(0) + ": " + categoryCounts.get(0));
        }
        if (categories.size() >= 2) {
            tvProduct2.setText(categories.get(1) + ": " + categoryCounts.get(1));
        }
        if (categories.size() >= 3) {
            tvProduct3.setText(categories.get(2) + ": " + categoryCounts.get(2));
        }
    }

    public void setBarChartData(List<String> labels, List<Integer> transactionCounts, int[] colorResources) {
        BarChart barChart = findViewById(R.id.monthlysalesbarchart);
        barChart.clearChart();

        for (int i = 0; i < labels.size(); i++) {
            int color = (i < colorResources.length)
                    ? ContextCompat.getColor(this, colorResources[i])
                    : ContextCompat.getColor(this, R.color.defaultColor);

            BarModel barModel = new BarModel(labels.get(i), transactionCounts.get(i), color);
            barChart.addBar(barModel);
        }

        barChart.startAnimation();
    }


}