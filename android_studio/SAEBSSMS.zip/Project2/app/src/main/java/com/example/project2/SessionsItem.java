package com.example.project2;

public class SessionsItem {

    private String username;
    private String fullname;
    private String loginTime;
    private String logoutTime;
    private String timeSpent;

    public SessionsItem(String username, String fullname, String loginTime, String logoutTime, String timeSpent) {
        this.username = username;
        this.fullname = fullname;
        this.loginTime = loginTime;
        this.logoutTime = logoutTime;
        this.timeSpent = timeSpent;
    }

    public String getUsername() {
        return username;
    }

    public String getFullname() {
        return fullname;
    }

    public String getLoginTime() {
        return loginTime;
    }

    public String getLogoutTime() {
        return logoutTime;
    }

    public String getTimeSpent() {
        return timeSpent;
    }
}

