package com.example.project2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.ViewHolder> {

    private List<TransactionItem> transactionItemList;

    public TransactionAdapter(List<TransactionItem> transactionItemList) {
        this.transactionItemList = transactionItemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        TransactionItem transactionItem = transactionItemList.get(position);

        holder.customerNameTextView.setText(transactionItem.getCustomerName());
        holder.transactionDateTextView.setText("Transaction Date: " + transactionItem.getTransactionDate());
        holder.totalPriceTextView.setText("Total Price: ₱ " + transactionItem.getTotalPrice());
    }

    @Override
    public int getItemCount() {
        return transactionItemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView customerNameTextView;
        public TextView transactionDateTextView;
        public TextView totalPriceTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            customerNameTextView = itemView.findViewById(R.id.customerNameTextView);
            transactionDateTextView = itemView.findViewById(R.id.transactionDateTextView);
            totalPriceTextView = itemView.findViewById(R.id.totalPriceTextView);
        }
    }
}
