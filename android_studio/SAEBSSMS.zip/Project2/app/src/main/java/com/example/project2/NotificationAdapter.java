package com.example.project2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.ViewHolder> {

    private List<NotificationItem> notificationItemList;

    public NotificationAdapter(List<NotificationItem> notificationItemList) {
        this.notificationItemList = notificationItemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_notification, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NotificationItem notificationItem = notificationItemList.get(position);

        holder.notificationTypeTextView.setText(notificationItem.getType());
        holder.notificationDateTextView.setText("Product Name: " + notificationItem.getDate());
        holder.quantityTextView.setText("Quantity: " + notificationItem.getQuantity());

        // Set text color based on notification type
        switch (notificationItem.getType()) {
            case "Low Stock":
                holder.notificationTypeTextView.setTextColor(Color.RED);
                break;
            case "Critical":
                holder.notificationTypeTextView.setTextColor(Color.parseColor("#FFA500")); // Orange color
                break;
            case "Restock":
                holder.notificationTypeTextView.setTextColor(Color.GREEN);
                break;
            default:
                // Handle other cases or set a default color
                holder.notificationTypeTextView.setTextColor(Color.BLACK);
                break;
        }
    }


    @Override
    public int getItemCount() {
        return notificationItemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public TextView notificationTypeTextView;
        public TextView notificationDateTextView;
        public TextView quantityTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            notificationTypeTextView = itemView.findViewById(R.id.notificationTypeTextView);
            notificationDateTextView = itemView.findViewById(R.id.notificationDateTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
        }
    }
}

