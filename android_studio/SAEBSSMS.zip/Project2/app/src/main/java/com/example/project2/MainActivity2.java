package com.example.project2;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private SearchView searchView;

    private final String URL = "https://saeb.lightsolus.xyz/android_studio/inventory.php";
    private Parcelable recyclerViewState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        searchView = findViewById(R.id.searchView);

        // Set a listener for the search view
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Handle search submission if needed
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Filter the RecyclerView based on the search query
                filterInventory(newText);
                return true;
            }
        });



// Set an OnClickListener for the entire SearchView
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle search click action here
                // You can open a search activity, expand the SearchView, or perform other actions
                // For example, you can also request focus to open the keyboard:
                searchView.onActionViewExpanded();
            }
        });

// Additionally, you can set an OnCloseListener to handle the close action:
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                // Handle search view close action if needed
                return false;
            }
        });

        // Set click listener for RecyclerView items
        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(this, recyclerView,
                new RecyclerItemClickListener.OnItemClickListener() {
                    @Override
                    public void onItemClick(View view, int position) {
                        // Handle item click, open the dialog
                        showProductDialog(position);
                    }

                    @Override
                    public void onLongItemClick(View view, int position) {
                        // Handle long item click if needed
                    }
                }));

        // Fetch inventory data when the activity is created
        fetchInventory();
    }

    private void filterInventory(String query) {
        // Perform filtering based on the query
        // Modify your processInventory method to consider the query
        // For simplicity, let's assume you have a method in InventoryAdapter for filtering
        if (recyclerView.getAdapter() instanceof InventoryAdapter) {
            ((InventoryAdapter) recyclerView.getAdapter()).filter(query);
        }
    }

    private void fetchInventory() {
        progressBar.setVisibility(View.VISIBLE);

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        processInventory(response);
                        progressBar.setVisibility(View.GONE);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.GONE);
                // Handle errors
                // Display an error message or log the error
            }
        });

        queue.add(jsonArrayRequest);
    }

    private void processInventory(JSONArray jsonArray) {
        List<InventoryItem> inventoryItemList = new ArrayList<>();

        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String productName = jsonObject.getString("productname");
                int quantity = jsonObject.getInt("quantity");
                int price = jsonObject.getInt("price");
                String imageUrl = jsonObject.getString("image_url");
                String newImage = "";
                if (!isValidWebsite(imageUrl)) {
                    newImage = "https://saeb.lightsolus.xyz/" + imageUrl;
                } else {
                    newImage = imageUrl;
                }
                InventoryItem inventoryItem = new InventoryItem(productName, quantity, price, newImage);
                inventoryItemList.add(inventoryItem);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        // Display inventory items using the InventoryAdapter
        InventoryAdapter inventoryAdapter = new InventoryAdapter(inventoryItemList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(inventoryAdapter);
    }



    private boolean isValidWebsite(String UrlCheck) {
        return android.util.Patterns.WEB_URL.matcher(UrlCheck).matches();
    }


    private void showProductDialog(int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_product_info, null);

        ImageView dialogImageView = dialogView.findViewById(R.id.dialogImageView);
        TextView dialogProductNameTextView = dialogView.findViewById(R.id.dialogProductNameTextView);
        TextView dialogDescriptionTextView = dialogView.findViewById(R.id.dialogDescriptionTextView);

        InventoryAdapter adapter = (InventoryAdapter) recyclerView.getAdapter();
        if (adapter != null) {
            InventoryItem selectedProduct = adapter.getItemAtPosition(position);

            if (selectedProduct != null) {
                // Load image using Picasso
                Picasso.get().load(selectedProduct.getImageUrl()).into(dialogImageView);

                // Set product name and description
                dialogProductNameTextView.setText(selectedProduct.getProductName());
                fetchProductDescription(selectedProduct.getProductName(), dialogDescriptionTextView);
            }
        }

        builder.setView(dialogView);
        AlertDialog dialog = builder.create();

        dialog.show();
    }



    // Method to fetch product description from the server (modify as needed)
    private void fetchProductDescription(String productName, TextView descriptionTextView) {

        RequestQueue queue = Volley.newRequestQueue(this);
        String productDescriptionURL = "https://saeb.lightsolus.xyz/android_studio/product_description.php?productname=" + productName;

        StringRequest stringRequest = new StringRequest(Request.Method.GET, productDescriptionURL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response and set it to the TextView
                        descriptionTextView.setText(response);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // Handle errors
                // Display an error message or log the error
            }
        });

        queue.add(stringRequest);
    }

}
