package com.example.project2;

public class Item {
    private int id;
    private String productName;
    private int quantity;

    private String imageUrl;
    public Item(int id, String productName, int quantity, String imageUrl) {
        this.id = id;
        this.productName = productName;
        this.quantity = quantity;
        this.imageUrl = imageUrl;
    }

    public int getId(){
        return id;
    }
    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    // Add the setter method for quantity
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    public String getImageUrl() {
        return imageUrl;
    }
}
