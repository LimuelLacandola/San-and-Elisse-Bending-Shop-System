package com.example.project2;

public class TransactionItem {
    private String customerName;
    private String transactionDate;
    private int totalPrice;

    public TransactionItem(String customerName, String transactionDate, int totalPrice) {
        this.customerName = customerName;
        this.transactionDate = transactionDate;
        this.totalPrice = totalPrice;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public int getTotalPrice() {
        return totalPrice;
    }
}
