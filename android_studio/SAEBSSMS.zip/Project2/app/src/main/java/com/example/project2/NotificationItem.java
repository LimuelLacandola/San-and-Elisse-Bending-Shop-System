package com.example.project2;

public class NotificationItem {
    private String type;
    private String date;
    private int quantity;

    public NotificationItem(String type, String date, int quantity) {
        this.type = type;
        this.date = date;
        this.quantity = quantity;
    }

    public String getType() {
        return type;
    }

    public String getDate() {
        return date;
    }

    public int getQuantity() {
        return quantity;
    }
}