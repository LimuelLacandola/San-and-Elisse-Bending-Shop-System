package com.example.project2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.util.Log;
import android.util.Pair;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private ArrayList<Item> itemList;
    private Context context;

    public ItemAdapter(Context context, ArrayList<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item currentItem = itemList.get(position);


        holder.productNameTextView.setText(currentItem.getProductName());
        holder.quantityTextView.setText(String.valueOf("Quantity: "+currentItem.getQuantity()));

        Picasso.get().load(currentItem.getImageUrl()).into(holder.imageView);


        // Set click listener for the CardView
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showQuantityInputDialog(currentItem);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public CardView cardView;
        public TextView productNameTextView;
        public TextView quantityTextView;
        public ImageView imageView;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.cardView);
            productNameTextView = itemView.findViewById(R.id.productNameTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }

    private void showQuantityInputDialog(Item currentItem) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Enter Quantity");

        View viewInflated = LayoutInflater.from(context).inflate(R.layout.dialog_quantity_input, null);
        final EditText inputQuantity = viewInflated.findViewById(R.id.inputQuantity);

        builder.setView(viewInflated);

        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String enteredQuantity = inputQuantity.getText().toString().trim();
                if (!enteredQuantity.isEmpty()) {
                    int quantityToAdd = Integer.parseInt(enteredQuantity);
                    int newQuantity =  quantityToAdd;
                    updateQuantityInDatabase(currentItem, newQuantity);
                }
            }
        });

        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        builder.show();
    }


    private static class UpdateQuantityTask extends AsyncTask<Pair<Integer, Integer>, Void, Void> {
        @Override
        protected Void doInBackground(Pair<Integer, Integer>... pairs) {
            Pair<Integer, Integer> pair = pairs[0];
            int id = pair.first;
            int quantityToAdd = pair.second;

            try {
                // Log item information for debugging
                Log.d("UpdateQuantityTask", "Updating quantity for item with id: " + id);

                // Construct the URL for your update_quantity.php endpoint
                URL url = new URL("https://saeb.lightsolus.xyz/android_studio/update_quantity.php");

                // Open connection
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("POST");

                // Set parameters for your request (you might need to customize this based on your server)
                String parameters = "id=" + id + "&quantityToAdd=" + quantityToAdd;

                // Log parameters for debugging
                Log.d("UpdateQuantityTask", "Sending parameters: " + parameters);

                // Enable input/output streams
                urlConnection.setDoOutput(true);
                OutputStream os = urlConnection.getOutputStream();
                os.write(parameters.getBytes());
                os.flush();
                os.close();

                // Get the response (optional)
                int responseCode = urlConnection.getResponseCode();
                Log.d("UpdateQuantityTask", "Response Code: " + responseCode);

                // Close connection
                urlConnection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }




    private void updateQuantityInDatabase(Item item, int quantityToAdd) {
        // Execute the AsyncTask to update the quantity in the database
        new UpdateQuantityTask().execute(new Pair<>(item.getId(), quantityToAdd));

        // Update the item in the itemList and notify the adapter
        int newQuantity = item.getQuantity() + quantityToAdd;
        item.setQuantity(newQuantity);
        notifyDataSetChanged();
    }

}

