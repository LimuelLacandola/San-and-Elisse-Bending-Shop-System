package com.example.project2;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity3 extends AppCompatActivity {

    private ProgressBar progressBar;
    private RecyclerView recyclerView;
    private List<SessionsItem> dataItemList;
    private SessionsAdapter dataAdapter;

    private Handler handler;
    private final int UPDATE_INTERVAL = 5000; // 5 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        progressBar = findViewById(R.id.progressBar);
        recyclerView = findViewById(R.id.recyclerView);
        dataItemList = new ArrayList<>();
        dataAdapter = new SessionsAdapter(dataItemList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(dataAdapter);

        // Initialize the handler
        handler = new Handler();

        // Fetch data immediately
        fetchData();

        // Schedule data update every 5 seconds
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchData();
                handler.postDelayed(this, UPDATE_INTERVAL);
            }
        }, UPDATE_INTERVAL);
    }

    private void fetchData() {
        progressBar.setVisibility(View.GONE);

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://saeb.lightsolus.xyz/android_studio/sessions.php";

        // Request a JSON response from the provided URL.
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        processData(response);
                        progressBar.setVisibility(View.GONE);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressBar.setVisibility(View.GONE);
                // Handle errors
                // Display an error message or log the error
            }
        });

        // Add the request to the RequestQueue.
        queue.add(jsonArrayRequest);
    }

    private void processData(JSONArray jsonArray) {
        dataItemList.clear(); // Clear existing data

        for (int i = 0; i < jsonArray.length(); i++) {
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);

                String username = jsonObject.getString("username");
                String fullname = jsonObject.getString("fullname");
                String loginTime = jsonObject.getString("login_time");
                String logoutTime = jsonObject.getString("logout_time");
                String timeSpent = jsonObject.getString("time_spent");

                SessionsItem dataItem = new SessionsItem(username, fullname, loginTime, logoutTime, timeSpent);
                dataItemList.add(dataItem);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        // Notify the adapter that the data set has changed
        dataAdapter.notifyDataSetChanged();
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Remove callbacks to prevent memory leaks
        handler.removeCallbacksAndMessages(null);
    }
}