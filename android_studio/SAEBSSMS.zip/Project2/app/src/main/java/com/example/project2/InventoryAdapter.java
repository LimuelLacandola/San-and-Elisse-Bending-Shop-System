package com.example.project2;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    private List<InventoryItem> originalList;
    private List<InventoryItem> filteredList;

    public InventoryAdapter(List<InventoryItem> inventoryItemList) {
        this.originalList = new ArrayList<>(inventoryItemList);
        this.filteredList = new ArrayList<>(inventoryItemList);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem inventoryItem = filteredList.get(position);

        holder.productNameTextView.setText(inventoryItem.getProductName());
        holder.quantityTextView.setText(String.valueOf("Quantity: " + inventoryItem.getQuantity() + " pcs"));
        holder.priceTextView.setText("Price: ₱" + inventoryItem.getPrice());

        int quantity = inventoryItem.getQuantity();
        String status;
        if (quantity >= 50) {
            status = "High Stock";
            holder.statusTextView.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.colorGreen));
        } else if (quantity < 50 && quantity > 20) {
            status = "Critical";
            holder.statusTextView.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.colorOrange));
        } else {
            status = "Low Stock";
            holder.statusTextView.setTextColor(ContextCompat.getColor(holder.itemView.getContext(), R.color.colorRed));
        }
        holder.statusTextView.setText(status);

        Picasso.get().load(inventoryItem.getImageUrl()).into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    public void filter(String query) {
        filteredList.clear();

        if (TextUtils.isEmpty(query)) {
            filteredList.addAll(originalList);
        } else {
            String lowerCaseQuery = query.toLowerCase().trim();

            for (InventoryItem item : originalList) {
                if (item.getProductName().toLowerCase().contains(lowerCaseQuery)) {
                    filteredList.add(item);
                }
            }
        }

        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView imageView;
        public TextView productNameTextView;
        public TextView quantityTextView;
        public TextView priceTextView;
        public TextView statusTextView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            productNameTextView = itemView.findViewById(R.id.productNameTextView);
            quantityTextView = itemView.findViewById(R.id.quantityTextView);
            priceTextView = itemView.findViewById(R.id.priceTextView);
            statusTextView = itemView.findViewById(R.id.statusTextView);
        }


        }
    public InventoryItem getItemAtPosition(int position) {
        if (position >= 0 && position < filteredList.size()) {
            return filteredList.get(position);
        } else {
            return null;
        }
    }
}
