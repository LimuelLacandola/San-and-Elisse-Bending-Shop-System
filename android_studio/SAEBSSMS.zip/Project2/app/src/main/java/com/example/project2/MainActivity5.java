package com.example.project2;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity5 extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Item> itemList;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        itemList = new ArrayList<>();

        // Replace "your_php_script_url" with the actual URL of your PHP script
        String phpScriptUrl = "https://saeb.lightsolus.xyz/android_studio/restock_items.php";

        // Execute AsyncTask to fetch data from the database
        new FetchDataTask().execute(phpScriptUrl);

        // Initialize the handler
        handler = new Handler(Looper.getMainLooper());

    }

    // AsyncTask to fetch data from the database
    private class FetchDataTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String result = "";
            try {
                URL url = new URL(urls[0]);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                InputStream inputStream = httpURLConnection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
                bufferedReader.close();
                inputStream.close();
                httpURLConnection.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        @Override
        protected void onPostExecute(String result) {
            try {
                JSONArray jsonArray = new JSONArray(result);
                itemList.clear(); // Clear existing data before adding new data
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    int id = jsonObject.getInt("id");
                    String productName = jsonObject.getString("productname");
                    int quantity = jsonObject.getInt("quantity");
                    String imageUrl = jsonObject.getString("image_url");

                    String newImage = "";
                    if (!isValidWebsite(imageUrl)) {
                        newImage = "https://saeb.lightsolus.xyz/" + imageUrl;
                    } else {
                        newImage = imageUrl;
                    }


                    // Display items with quantity <= 20
                    if (quantity <= 20) {
                        itemList.add(new Item(id, productName, quantity, newImage));
                    }

                }

                // Set up the RecyclerView adapter
                ItemAdapter adapter = new ItemAdapter(MainActivity5.this, itemList);
                recyclerView.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    protected void onDestroy() {
        // Remove the callback when the activity is destroyed to prevent memory leaks
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private boolean isValidWebsite(String UrlCheck) {
        return android.util.Patterns.WEB_URL.matcher(UrlCheck).matches();
    }
}
