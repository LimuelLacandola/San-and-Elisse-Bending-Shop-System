<?php
require_once 'db_connection.php';

$productId = $_GET['id'];

// Prepare and execute the SQL query to fetch product information by ID
$query = "SELECT * FROM inventory WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $productId);
$stmt->execute();
$result = $stmt->get_result();

// Display product information in the modal
if ($result->num_rows > 0) {
    $product = $result->fetch_assoc();
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Edit Product Information</title>

        <!-- Add your existing styles and scripts -->
        <style>
            .modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
    background-color: #fefefe;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    border-radius: 10px;
    text-align: center;
}



       .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }

        /* Center the form within the modal */
        .form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .title {
            align-items: center;
            font-size: 28px;
            color: #333;
            font-weight: 600;
            letter-spacing: -1px;
            position: relative;
            display: flex;
            align-items: center;
            padding-left: 30px;
            justify-content: center; /* Center the title horizontally */
        }

        .flex {
            display: flex;
            width: 100%;
            gap: 6px;
        }

        .form label {
            position: relative;
            margin-bottom: 10px;
        }

        .form label .input {
            width: 100%;
            padding: 10px 10px 20px 10px;
            outline: 0;
            border: 1px solid rgba(105, 105, 105, 0.397);
            border-radius: 10px;
        }

        .form label .input + span {
            position: absolute;
            left: 10px;
            top: 15px;
            color: grey;
            font-size: 0.9em;
            cursor: text;
            transition: 0.3s ease;
        }

        .form label .input:placeholder-shown + span {
            top: 15px;
            font-size: 0.9em;
        }

        .form label .input:focus + span, .form label .input:valid + span {
            top: 30px;
            font-size: 0.7em;
            font-weight: 600;
        }

        .form label .input:valid + span {
            color: #333;
        }

        .submit {
            border: none;
            outline: none;
            background-color: #333;
            padding: 10px;
            border-radius: 10px;
            color: white;
            font-size: 16px;
            transform: .3s ease;
        }

        .submit:hover {
            background-color: rgb(56, 90, 194);
        }
    </style>
</head>
<body>
    <h2 class="title">Edit Product Information</h2>
    <form id="updateProductForm" action="update_product.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="productId" value="<?= $product['id'] ?>">
        <label for="productName" class="form-label">
            Product Name:
            <input type="text" id="productName" name="productName" value="<?= $product['productname'] ?>" required class="input">
        </label>
        
        <label for="brand" class="form-label">
            Brand:
            <input type="text" id="brand" name="brand" value="<?= $product['brand'] ?>" required class="input">
        </label>

        <label for="category" class="form-label">
            Category:
            <input type="text" id="category" name="category" value="<?= $product['category'] ?>" required class="input">
        </label>

        <label for="description" class="form-label">
            Description:
            <input type="text" id="description" name="description" value="<?= $product['description'] ?>" required class="input">
        </label>

        <label for="quantity" class="form-label">
            Quantity:
            <input type="number" id="quantity" name="quantity" value="<?= $product['quantity'] ?>" required class="input">
        </label>
        
        <label for="measurement" class="form-label">
            Measurement:
            <input type="text" id="measurement" name="measurement" value="<?= $product['measurement'] ?>" required class="input">
        </label>

        <label for="price" class="form-label">
            Price:
            <input type="number" step="0.01" id="price" name="price" value="<?= $product['price'] ?>" required class="input">
        </label>

        <label for="imageFile" class="form-label">
                New Image:
                <input type="file" id="imageFile" name="imageFile" accept="image/*">
            </label>

            <img src="<?= $product['image_url'] ?>" alt="Current Image" style="max-width: 300px;">

        
        <label for="supplierName" class="form-label">
            Supplier Name:
            <input type="text" id="supplierName" name="supplierName" value="<?= $product['supplier_name'] ?>" required class="input">
        </label>
        
        <label for="supplierEmail" class="form-label">
            Supplier Email:
            <input type="text" id="supplierEmail" name="supplierEmail" value="<?= $product['supplier_email'] ?>" required class="input">
        </label>
        
                 

        <!-- Add additional fields as needed -->

        <input type="submit" value="Save" class="submit">
    </form>


        <!-- Add your existing scripts if needed -->

    </body>
    </html>

    <?php
} else {
    echo 'Product not found.';
}

$stmt->close();
$conn->close();
?>
