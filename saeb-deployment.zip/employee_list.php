<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

require_once 'db_connection.php';
require_once 'access_control.php';

$userRole = $_SESSION['user_role'];
restrictAccessToEmployee($userRole);


// Retrieve user information from the login table based on the username
$sql = "SELECT id, user_image, fullname, username, user_role FROM login WHERE username = '{$_SESSION['username']}'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch the user data
    $userData = $result->fetch_assoc();
} else {
    echo "User not found";
}



?>

<!DOCTYPE html>
<html>
<head>
    <link rel = "icon" href =  
"https://z-p3-scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/397997179_250856261335004_614763989636093522_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFAQHoVlJwD-o722MTZbqjNdAN0zl-EgQB0A3TOX4SBAHo4-7I3jVCp1ZpSpzk8h8rreNXwovhcMiIAX8vJlzwe&_nc_ohc=UQ2ASeBN5AcAX9ZRE0z&_nc_oc=AQkjY3_LMBhKeGNlIaHR_Lkk6QJundYBnfwKzhTqTuJifJSEJ47zDdUHEIXCOTu3qVgB3xJC2qq1RDl9iBC9HN8c&_nc_ht=z-p3-scontent.fmnl33-3.fna&oh=03_AdQQX55ul_5PZ8nuIHCCl3WQJaXGzIyLZjsylDCapniYLw&oe=65869B24" 
        type = "image/x-icon"> 
        
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Employee List</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');
        body {
            margin: 0;
            display: flex;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            -moz-transform: scale(0.75, 0.75); /* Moz-browsers */
             zoom: 0.75; /* Other non-webkit browsers */
              zoom: 75%; /* Webkit browsers */
        }
        .content {
            flex: 1;
            padding: 20px;
            
        }
        
  .navigation {
            background-color: #333;
            color: #fff;
            width: 250px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            transition: width 0.5s ease; /* Add transition for smoother resizing */

            
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            padding: 10px; /* Add padding for better hover effect */
    border-radius: 8px; /* Add border radius */
    transition: background-color 0.3s ease, color 0.3s ease; /* Add transitions for background and text color */
        }
        
        .navigation a:not(:last-child) {
            margin-bottom: 10px;
        }
        .navigation a:hover {
                background-color: #cccccc; /* Change background color on hover */
    color: #333; /* Change text color on hover */
    text-decoration: none; /* Remove underline on hover */
        }
        
        .navigation i {
    margin-right: 10px; /* Adjust the space between icon and text */
        vertical-align: middle; /* Align the icon vertically in the middle */
        margin-bottom: 8px;

}

        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 8px !important; /* Add rounded borders to the table */
            margin-top: 20px; /* Add some space above the table */
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: #f2f2f2;
        }
                tr:hover {
    background-color: #f5f5f5;
}
        .pagination {
            display: flex;
            list-style: none;
            padding: 0;
            justify-content: center;
        }

        .pagination li {
            margin-right: 5px;
        }

        .pagination button {
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            padding: 5px 10px;
            cursor: pointer;
            margin-right: 10px;
            text-align: center;
        }

        .pagination button:hover {
            background-color: #666;
        }
		
  /* Add styles for the modal */
    
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
    background-color: #fefefe;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    border-radius: 10px;
    text-align: center;
}



       .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
/* Center the form within the modal */
form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.title {
align-items: center;
  font-size: 28px;
  color: #333;
  font-weight: 600;
  letter-spacing: -1px;
  position: relative;
  display: flex;
  align-items: center;
  padding-left: 30px;
justify-content: center; /* Center the title horizontally */

}



.flex {
  display: flex;
  width: 100%;
  gap: 6px;
}

.form label {
  position: relative;
  margin-bottom: 10px;

}

.form label .input {
  width: 100%;
  padding: 10px 10px 20px 10px;
  outline: 0;
  border: 1px solid rgba(105, 105, 105, 0.397);
  border-radius: 10px;
}

.form label .input + span {
  position: absolute;
  left: 10px;
  top: 15px;
  color: grey;
  font-size: 0.9em;
  cursor: text;
  transition: 0.3s ease;
}

.form label .input:placeholder-shown + span {
  top: 15px;
  font-size: 0.9em;
}

.form label .input:focus + span,.form label .input:valid + span {
  top: 30px;
  font-size: 0.7em;
  font-weight: 600;
}

.form label .input:valid + span {
  color: #333;
}

.submit {
  border: none;
  outline: none;
  background-color: #333;
  padding: 10px;
  border-radius: 10px;
  color: white;
  font-size: 16px;
  transform: .3s ease;
}

.submit:hover {
  background-color: rgb(56, 90, 194);
}


    
    
        #searchBox {
  border: 2px solid transparent;
  width: 15em;
  height: 2.5em;
  padding-left: 0.8em;
  outline: none;
  overflow: hidden;
  background-color: #F3F3F3;
  border-radius: 10px;
  transition: all 0.5s;
}

#searchBox:hover,
#searchBox:focus {
  border: 2px solid #333;
  box-shadow: 0px 0px 0px 7px rgb(102, 102, 102, 20%);
  background-color: white;
}

    #usernameResult {
        margin-left: 10px; /* Adjust the margin as needed */
        color: black; /* Adjust the color as needed */
    }

.button {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: rgb(20, 20, 20);
  border: none;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.164);
  cursor: pointer;
  transition-duration: .3s;
  overflow: hidden;
  position: relative;
}

.svgIcon {
  width: 12px;
  transition-duration: .3s;
}

.svgIcon path {
  fill: white;
}

.button:hover {
  width: 140px;
  border-radius: 50px;
  transition-duration: .3s;
  background-color: rgb(255, 69, 69);
  align-items: center;
}



.button::before {
  position: absolute;
  top: -20px;
  content: "Add new user";
  color: white;
  transition-duration: .3s;
  font-size: 2px;
}

.button:hover::before {
  font-size: 13px;
  opacity: 1;
  transform: translateY(30px);
  transition-duration: .3s;
}

                .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            display: none;
        }

.loader {
  --dim: 3rem;
  width: var(--dim);
  height: var(--dim);
  position: relative;
  animation: spin988 2s linear infinite;
}

.loader .circle {
  --color: #333;
  --dim: 1.2rem;
  width: var(--dim);
  height: var(--dim);
  background-color: var(--color);
  border-radius: 50%;
  position: absolute;
}

.loader .circle:nth-child(1) {
  top: 0;
  left: 0;
}

.loader .circle:nth-child(2) {
  top: 0;
  right: 0;
}

.loader .circle:nth-child(3) {
  bottom: 0;
  left: 0;
}

.loader .circle:nth-child(4) {
  bottom: 0;
  right: 0;
}

@keyframes spin988 {
  0% {
    transform: scale(1) rotate(0);
  }

  20%, 25% {
    transform: scale(1.3) rotate(90deg);
  }

  45%, 50% {
    transform: scale(1) rotate(180deg);
  }

  70%, 75% {
    transform: scale(1.3) rotate(270deg);
  }

  95%, 100% {
    transform: scale(1) rotate(360deg);
  }
}


        .user-info {
            margin-top: auto;
            display: flex;
            align-items: center;
            text-decoration: none; /* Remove underline from the link */
            color: #fff;
        }

        .user-info img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 50%;
        }
        
        #logoLink img {
        width: 250px; /* Adjust the width as needed */
        height: auto; /* Maintains the aspect ratio */
        margin-bottom: -10px; /* Adjust this value to fine-tune the alignment */
        margin-left: -52px;
    }
    
    label {
    position: relative;
}

.show-password-checkbox {
    position: absolute;
    top: 45%;
    right: -10px;
    transform: translateY(-50%);
}

.eye-icon-container {
    position: absolute;
    top: 50%;
    right: -10px;
    transform: translateY(-50%);
    cursor: pointer;
}

.eye-icon {
    width: 24px; /* Adjust the width as needed */
    height: 24px; /* Adjust the height as needed */
    transition: opacity 0.3s;
}

.eye-icon:hover {
    opacity: 0.7;
}
    </style>
</head>
<body>
    
                <div class="loader-container" id="loaderContainer">
        <div class="loader">
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
</div>

    </div>
    

    <div class="navigation">
    <a href="index.php" id="logoLink">
        <img src="images/saebs_logo.png" alt="Logo">
    </a>
    <a href="index.php"><i class="material-icons">home</i> Home</a>
    <a href="inventory.php"><i class="material-icons">handyman</i> Inventory</a>
    <a href="notification.php"><i class="material-icons">notifications</i>Notifications</a>

    <a href="pos.php"><i class="material-icons">point_of_sale</i> Point of Sale</a>
    <!-- <a href="sales_report.php"><i class="material-icons">insert_chart_outlined</i> Sales Report</a> -->
    <a href="transaction_history.php"><i class="material-icons">receipt_long</i> Transaction History</a>
    <a href="refund.php"><i class="material-icons">history</i> Refund</a>


    <?php
    if ($_SESSION['user_role'] === 'admin') {
        echo '<a href="employee_list.php"><i class="material-icons">groups</i> Employee List</a>';
        echo '<a href="restock.php"><i class="material-icons">inventory</i> Restock</a>';
        echo '<a href="supplier.php"><i class="material-icons">local_shipping</i> Supplier</a>';
        echo '<a href="view_sessions.php"><i class="material-icons">access_time</i> Sessions</a>';
        
    } elseif ($_SESSION['user_role'] === 'employee') {
        // Employee can only access limited features
    } else {
        echo "Invalid user role.";
    }
    ?>
    
    <a href="restock_history.php"><i class="material-icons">manage_history</i> Restock History</a>
    <a href="logout.php" id="logoutLink"><i class="material-icons">logout</i> Logout</a>

    <?php
    // Check if the user has a custom image, otherwise, display a default image
    $userImage = isset($userData["user_image"]) ? $userData["user_image"] : "path/to/default-image.png";
    ?>
    <a href="user_info.php" class="user-info">
        <img src="<?php echo $userImage; ?>" alt="User Image">
    </a>
</div>
    
<div class="content">
    <h2>Employee List</h2>
    <div style="display: flex; align-items: center;">
    <input type="text" id="searchBox" placeholder="Search items">
     <button class="button" id="addUserBtn">
  <svg viewBox="0 0 448 512" class="svgIcon">
    <path d="M224 48h-32v160H48v32h144v144h32V240h144v-32H224z"></path>
</svg>

</button>
</div>
	





<!-- Modal for adding/editing a user -->
<div id="addEditUserModal1" class="modal">
    <div class="modal-content">
        <span class="close" id="closeModal">&times;</span>
        <h2 class="title">Add New User</h2>
        <form id="addEditUserForm" method="post" action="add_user.php" class="form" enctype="multipart/form-data">
            <label for="fullname">
                <input type="text" id="fullname" name="fullname" class="input" required>
                <span>Full Name</span>
            </label>
            
            
<label for="username" style="position: relative;">
    <input type="text" id="username" name="username" class="input" required>
    <span class="label-text">Username</span>
        <div id="usernameResult" style="position: relative;"></div>

</label>




<label for="password" style="position: relative;">
    <input type="password" id="password" name="password" class="input" required>
    <span>Password</span>
    <span id="eyeIcon" class="eye-icon-container">
        <img id="closedEye" class="eye-icon" src="images/hide.png" alt="Closed Eye">
        <img id="openEye" class="eye-icon" src="images/show.png" alt="Open Eye" style="display: none;">
    </span>
</label>

            

            <label for="user_role">
                <select id="user_role" name="user_role" class="input" required>
                    <option value="admin">Admin</option>
                    <option value="employee">Employee</option>
                </select>
                <span>User Role</span>
            </label>

            <label for="user_image">
    <input type="file" id="user_image" name="user_image" class="input" accept="image/*">
    <span>Upload User Image</span>
</label>



            <!-- Add a hidden input for user ID -->
            <input type="hidden" id="user_id" name="user_id">
            <input type="submit" value="Save" class="submit">
        </form>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get the input field for the password
        const passwordInput = document.getElementById('password');
        // Get the eye icons
        const openEyeIcon = document.getElementById('openEye');
        const closedEyeIcon = document.getElementById('closedEye');
        // Get the eye icon container
        const eyeIconContainer = document.getElementById('eyeIcon');

        // Add an event listener to the eye icon container
        eyeIconContainer.addEventListener('click', function () {
            // Toggle the visibility of the eye icons
            openEyeIcon.style.display = openEyeIcon.style.display === 'none' ? 'block' : 'none';
            closedEyeIcon.style.display = closedEyeIcon.style.display === 'none' ? 'block' : 'none';

            // Change the type attribute of the password input based on eye icon visibility
            passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
        });
    });
</script>



<!-- Add the following script just before the closing </body> tag -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Show loader on form submission
        document.getElementById('loaderContainer').style.display = 'flex';

        // Redirect to login.php after a delay (adjust as needed)
        setTimeout(function () {
           document.getElementById('loaderContainer').style.display = 'none';
        }, 1000); // Redirect after 1 second (1000 milliseconds)
   
    
    // Get the input field for username
    const usernameInput = document.getElementById('username');
    
    // Get the result display container
const resultDisplay = document.getElementById('usernameResult');

    

    // Add an event listener to the username input
    usernameInput.addEventListener('input', function () {
        const username = this.value.trim();

        // Send an AJAX request to check the username
        fetch('check_username.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `username=${username}`,
        })
        .then(response => response.json())
        .then(data => {
            // Update UI based on the response
            if (data.status === 'available') {
                // Username is available
                // You can add visual feedback here (e.g., change color or icon)
                resultDisplay.textContent = 'Username is available';
                resultDisplay.style.color = 'green'; // Adjust styling as needed
            } else if (data.status === 'taken') {
                // Username is taken
                // You can add visual feedback here (e.g., change color or icon)
                resultDisplay.textContent = 'Username is taken';
                resultDisplay.style.color = 'red'; // Adjust styling as needed
            } else {
                // Handle other status or errors
                resultDisplay.textContent = 'Error checking username';
                resultDisplay.style.color = 'orange'; // Adjust styling as needed
            }
        })
        .catch(error => {
            resultDisplay.textContent = 'Error checking username';
            resultDisplay.style.color = 'orange'; // Adjust styling as needed
            console.error('Error checking username', error);
        });
    });
});
</script>

<script>
    // Function to close the modal and redirect to "employee_list.php"
    function closeModalAndRedirect() {
        const modal = document.getElementById("closeModal");
        modal.style.display = "none";

        // Redirect to "employee_list.php"
        window.location.href = "employee_list.php";
    }

    // Add an event listener to the close button
    const closeModalButton = document.getElementById("closeModal");
    closeModalButton.addEventListener("click", closeModalAndRedirect);

</script>



<script>
    // Get the modal and button elements
    const addUserModal = document.getElementById('addEditUserModal1');
    const addUserBtn = document.getElementById('addUserBtn');
    const closeModal = document.getElementById('closeModal');

    // Show the modal when the button is clicked
    addUserBtn.addEventListener('click', () => {
        addUserModal.style.display = 'block';
    });

    // Close the modal when the close button is clicked
    closeModal.addEventListener('click', () => {
        addUserModal.style.display = 'none';
    });

    // Close the modal when clicking outside of it
    window.addEventListener('click', (event) => {
        if (event.target === addUserModal) {
            addUserModal.style.display = 'none';
        }
    });

    // Prevent the click inside the modal from closing it
    addUserModal.addEventListener('click', (event) => {
        event.stopPropagation();
    });
</script>
	
	
    <div id="employeeTable"></div>
	
	<script>


    // Function to handle delete button click
    function deleteUser(id) {
        // Implement the logic to delete the user with the given id
        // You can confirm the deletion and send an AJAX request to delete the user
        if (confirm(`Are you sure you want to delete user with ID: ${id}?`)) {
            // Send an AJAX request to delete the user (You'll need to implement this)
            // After successful deletion, you can reload the table or update it as needed
            alert(`User with ID: ${id} has been deleted.`);
            updateEmployee('', currentPage); // Refresh the table
        }
    }
</script>
	

	
	<script>
    // Function to update the employee table with pagination and edit/delete buttons
    function updateEmployee(searchTerm, page) {
        const employeeTable = document.getElementById('employeeTable');
        // ... (Your existing JavaScript code)

    }

    // Function to handle delete button click
    function deleteUser(id) {
        if (confirm(`Are you sure you want to delete user with ID: ${id}?`)) {
            // Send an AJAX request to delete the user
            fetch(`delete_user.php?id=${id}`, { method: 'DELETE' })
                .then(response => {
                    if (response.status === 200) {
                        // User deleted successfully
                        alert(`User with ID: ${id} has been deleted successfully.`);
                        updateEmployee('', currentPage);
						window.location.href = 'employee_list.php';
                    } else {
                        // Handle errors
                        alert(`Error deleting user with ID: ${id}`);
                    }
                });
        }
    }
</script>

<script>
// Get the modal and button elements
const addUserModal = document.getElementById('addEditUserModal');
const addUserBtn = document.getElementById('addUserBtn');
const closeModal = document.getElementById('closeModal');
const modalTitle = document.getElementById('modalTitle');
const userIdField = document.getElementById('user_id');

// Show the modal when the button is clicked
addUserBtn.addEventListener('click', () => {
    modalTitle.textContent = 'Add New User'; // Set the modal title
    userIdField.value = ''; // Reset the user ID field
    addUserModal.style.display = 'block';
});

// Close the modal when the close button is clicked
closeModal.addEventListener('click', () => {
    addUserModal.style.display = 'none';
});

// Close the modal when clicking outside of it
window.addEventListener('click', (event) => {
    if (event.target === addUserModal) {
        addUserModal.style.display = 'none';
    }
});

// Prevent the click inside the modal from closing it
addUserModal.addEventListener('click', (event) => {
    event.stopPropagation();
});

// Function to handle the form submission for adding a new user
addEditUserForm.addEventListener('submit', function (e) {
    e.preventDefault();

    // Collect form data
    const formData = new FormData(addEditUserForm);

    // Send an AJAX request to add the new user
    fetch('add_user.php', {
        method: 'POST',
        body: formData,
    })
    .then(response => {
        if (response.status === 200) {
            // User added successfully
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: 'User has been added successfully.',
            }).then(() => {
                addUserModal.style.display = 'none'; // Close the modal
                updateEmployee('', currentPage); // Refresh the employee table
            });
        } else {
            // Handle errors
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Error adding user.',
            });
        }
    });
});
</script>




    <script>
// Remove the pagination related code and simplify the script
document.getElementById('searchBox').addEventListener('input', function () {
    const searchTerm = this.value.toLowerCase().trim();
    updateEmployee(searchTerm);
});

// Initial table update without search term
updateEmployee('');

// Function to update the employee table with all data
function updateEmployee(searchTerm) {
    const employeeTable = document.getElementById('employeeTable');

    // Send an AJAX request to fetch all employee data with the search term
    fetch(`fetch_employee_list.php?search=${searchTerm}`)
        .then(response => response.text())
        .then(data => {
            employeeTable.innerHTML = data;
        });
}

    </script>
    
    
	
</div>
</body>
</html>