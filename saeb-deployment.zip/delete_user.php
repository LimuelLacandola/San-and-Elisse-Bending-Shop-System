<?php
require_once 'db_connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    // Handle user deletion
    $id = $_GET['id'];
    $query = "DELETE FROM login WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        http_response_code(200); // Success
    } else {
        http_response_code(500); // Internal Server Error
    }

    $stmt->close();
    $conn->close();
}
?>
