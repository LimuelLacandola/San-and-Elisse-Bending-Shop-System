<?php
// Database connection
require_once 'db_connection.php';


$products = [];
$query = "SELECT id, productname, price, quantity, image_url FROM inventory";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $products[] = [
            'id' => $row['id'],
            'name' => $row['productname'],
            'value' => $row['price'],
            'quantity' => $row['quantity'],
            'image' => $row['image_url']
        ];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel = "icon" href =  
"https://z-p3-scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/397997179_250856261335004_614763989636093522_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFAQHoVlJwD-o722MTZbqjNdAN0zl-EgQB0A3TOX4SBAHo4-7I3jVCp1ZpSpzk8h8rreNXwovhcMiIAX8vJlzwe&_nc_ohc=UQ2ASeBN5AcAX9ZRE0z&_nc_oc=AQkjY3_LMBhKeGNlIaHR_Lkk6QJundYBnfwKzhTqTuJifJSEJ47zDdUHEIXCOTu3qVgB3xJC2qq1RDl9iBC9HN8c&_nc_ht=z-p3-scontent.fmnl33-3.fna&oh=03_AdQQX55ul_5PZ8nuIHCCl3WQJaXGzIyLZjsylDCapniYLw&oe=65869B24" 
        type = "image/x-icon"> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

    body {
font-family: 'Poppins', sans-serif;
  color: #56514B;
  font-size: 16px;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center; /* Center horizontally */
  -moz-transform: scale(0.75, 0.75); /* Moz-browsers */
             zoom: 0.75; /* Other non-webkit browsers */
              zoom: 75%; /* Webkit browsers */
}
body.bill {
  flex-direction: column;
}

.search-bar {
  margin-top: 1rem;
  text-align: center;
}
.search-bar input {
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.customer-name {
  margin-top: 1rem;
}
.customer-name input {
  padding: 0.5rem;
  border: 1px solid #ccc;
  border-radius: 5px;
}

.products {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  max-width: 1200px; /* Adjust as needed */
  flex: 0 0 calc(70% - 1rem);
}
.product {
  background-color: #E7E5DD;
  color: black;
  border-radius: 10px;
  box-sizing: border-box;
  padding: 1rem;
  position: relative;
  margin: 1rem;
  flex: 0 0 20%;
  text-align: center;
  cursor: pointer;
}   

.bill {
  
  flex: 0 0 calc(30% - 1rem); /* Adjust the calculation as needed */
}

section.products {
  flex: 0 0 70%;
  display: flex;
  flex-direction: row;
  flex-wrap: wrap;
  justify-content: space-between;
}
section.products > div {
  background-color: #E7E5DD;
  border-radius: 10px;
  box-sizing: border-box;
  padding: 1rem;
  position: relative;
  margin: 1rem;
  flex: 0 0 20%;
  text-align: center;
  cursor: pointer;
}
.product-quantity {
    font-size: 14px;
    color: black;
}

/* Solving click event bug */
section.products > div:after {
  content: '';
  display: block;
  position: absolute;
  width: 100%;
  height: 100%;
  top: 0;
  left: 0;
}
section.products > div > img {
  max-height: 5rem;
  max-width: 5rem;
  margin-bottom: 1rem;
}
section.products > div > p {
  margin: 0;
  padding: 0;
}       
.hidden {
	display: none;
}
.back-button {
        position: absolute;
        top: 10px;
        left: 10px;
    }

    .back-button a {
        display: inline-block;
        padding: 10px 15px;
        background-color: #333;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
    }

    .back-button a:hover {
        background-color: #555;
    }

    .checkout{
        position: absolute;
    }

    .checkout a {
        display: inline-block;
        padding: 10px 15px;
        background-color: #333;
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
    }

    .checkout a:hover {
        background-color: #555;
    }

    .product.disabled {
            cursor: not-allowed;
            opacity: 0.5;
        }
    .content-container {
        display: flex;
        justify-content: space-between;
        max-width: 1200px; /* Adjust as needed */
        margin: 0 auto;
}

button {
 appearance: none;
 background-color: transparent;
 border: 0.125em solid #1A1A1A;
 border-radius: 8px;
 box-sizing: border-box;
 color: #3B3B3B;
 cursor: pointer;
 display: inline-block;
 font-family: Roobert,-apple-system,BlinkMacSystemFont,"Segoe UI",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol";
 font-size: 16px;
 font-weight: 600;
 line-height: normal;
 margin: 0;
 min-width: 0;
 outline: none;
padding: .3em 1em;
 text-align: center;
 text-decoration: none;
 transition: all 300ms cubic-bezier(.23, 1, 0.32, 1);
 user-select: none;
 -webkit-user-select: none;
 touch-action: manipulation;
 will-change: transform;
}

button:disabled {
 pointer-events: none;
}

button:hover {
 color: #fff;
 background-color: #1A1A1A;
 box-shadow: rgba(0, 0, 0, 0.25) 0 8px 15px;
 transform: translateY(-2px);
}

button:active {
 box-shadow: none;
 transform: translateY(0);
}

  .payment-modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.5);
    }

    .payment-modal-content {
        background-color: #fefefe;
        margin: 10% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 60%;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        border-radius: 10px;
        position: relative;
    }

    .close-modal {
        color: #aaa;
        position: absolute;
        top: 10px;
        right: 10px;
        font-size: 28px;
        font-weight: bold;
        cursor: pointer;
    }

    /* Style for the payment form */
    .payment-form {
        display: flex;
        flex-direction: column;
    }

    .payment-form label {
        margin-bottom: 8px;
    }

    .payment-form select,
    .payment-form input {
        padding: 10px;
        margin-bottom: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-sizing: border-box;
        width: 100%;
    }

    .payment-form button {
        padding: 10px;
        background-color: #333;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .payment-form button:hover {
        background-color: #555
}

.selected-product-quantity-input {
    width: 30px; /* Adjust the width as needed */
}

.remove-product {
    margin-left: 10px; /* Adjust the spacing as needed */
}

#out-of-stock-label {
        background-color: #ccc;
        color: #555;
        padding: 0.5rem;
        border-radius: 5px;
        text-align: center;
        font-weight: bold;
    }
    
                .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            display: none;
        }

.loader {
  --dim: 3rem;
  width: var(--dim);
  height: var(--dim);
  position: relative;
  animation: spin988 2s linear infinite;
}

.loader .circle {
  --color: #333;
  --dim: 1.2rem;
  width: var(--dim);
  height: var(--dim);
  background-color: var(--color);
  border-radius: 50%;
  position: absolute;
}

.loader .circle:nth-child(1) {
  top: 0;
  left: 0;
}

.loader .circle:nth-child(2) {
  top: 0;
  right: 0;
}

.loader .circle:nth-child(3) {
  bottom: 0;
  left: 0;
}

.loader .circle:nth-child(4) {
  bottom: 0;
  right: 0;
}

@keyframes spin988 {
  0% {
    transform: scale(1) rotate(0);
  }

  20%, 25% {
    transform: scale(1.3) rotate(90deg);
  }

  45%, 50% {
    transform: scale(1) rotate(180deg);
  }

  70%, 75% {
    transform: scale(1.3) rotate(270deg);
  }

  95%, 100% {
    transform: scale(1) rotate(360deg);
  }
}

    /* Add these styles for the disabled button */
    .payment-form button:disabled {
        background-color: #e0e0e0; /* Change the background color */
        color: #a0a0a0; /* Change the text color */
        cursor: not-allowed; /* Change the cursor */
    }

    .payment-form button:disabled:hover {
        background-color: #e0e0e0; /* Change the background color on hover */
        color: #a0a0a0; /* Change the text color on hover */
        cursor: not-allowed; /* Change the cursor on hover */
    }

    </style>
</head>
<body>
                <div class="loader-container" id="loaderContainer">
        <div class="loader">
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
</div>

    </div>
    
<div class="search-bar">
    <!-- Search bar -->
    <input type="text" name="search" id="searchInput" placeholder="Search items">
</div>

<div class="content-container">
    <section class="products" style="max-height: 120vh; overflow-y: auto;">
        <p id="noItemsFound" style="display: none;">No items found.</p>
        <?php foreach ($products as $product) { ?>
            <div class="product <?php echo $product['quantity'] === 0 ? 'disabled' : ''; ?>"
                 data-index="<?php echo $product['id']; ?>"
                 data-name="<?php echo $product['name']; ?>"
                 data-value="<?php echo $product['value']; ?>"
                 data-quantity="<?php echo $product['quantity']; ?>"
                 data-image="<?php echo $product['image']; ?>"
                 data-price="<?php echo $product['value']; ?>">
                <?php if ($product['quantity'] === 0) { ?>
                    <p class="out-of-stock-label">Out of Stock</p>
                <?php } else { ?>
                    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                <?php } ?>
                <p class="product-name"><?php echo $product['name']; ?></p>
                <p class="product-value">₱<?php echo $product['value']; ?></p>
                <p class="product-quantity">Quantity: <?php echo $product['quantity']; ?></p>
            </div>
        <?php } ?>
    </section>

    <section class="bill">
        <div class="bill-products">
            <h2>Selected Items</h2>
        </div>
        <div class="bill-client">
            <form method="POST" action="./bill.php">
                <div class="hidden">
                    <label for="products">Products</label>
                    <input type="text" name="products" id="products" placeholder="Products ID" value="">
                </div>
                <div class="customer-name">
                    <input type="text" name="name" id="name" placeholder="Customer Name" required>
                </div>
                <input type="hidden" name="payment_method" id="paymentMethodInput" value="">
    <input type="hidden" name="amount_paid" id="amountPaidInput" value="">
                <div class="checkout">
                    <br><button>Check out</button>
                </div>
                <div class="back-button">
                    <a href="index.php">Home</a>
                </div>
            </form>
        </div>
    </section>
    
    <div class="payment-modal" style="display: none;">
    <div class="payment-modal-content">
        <span class="close-modal" onclick="closePaymentModal()">&times;</span>
        <h2>Choose Payment Method</h2>
                <!-- Display selected items and their total amount -->
        <div id="selectedItems">
            <!-- The selected items will be dynamically added here -->
        </div>

        <div id="totalAmountContainer">
            <p>Amount to pay: <span id="totalAmount">₱0.00</span></p>
        </div>
        <form class="payment-form">
            <label for="payment-method">Payment Method:</label>
            <select id="payment-method" name="payment-method">
    <option value=""></option>
    <option value="Cash">Cash</option>
    <option value="Maya">Maya</option>
    <option value="Gcash">GCash</option>
</select>
            <label for="amount">Payment amount:</label>
            <p id="invalidAmount" style="color: red;">Invalid amount</p>
            <input type="number" id="amount" name="amount" required>
            <button type="submit">Proceed</button>
        </form>
    </div>
</div>
    
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const products = document.querySelectorAll('.product');
        const searchInput = document.getElementById('searchInput');
        const noItemsFoundMessage = document.getElementById('noItemsFound');

        // Initial list of all products
        let allProducts = [...products];

        // Add an input event listener to the search input
        searchInput.addEventListener('input', function () {
            const searchTerm = searchInput.value.toLowerCase();

            // Filter products based on the search term
            const matchingProducts = allProducts.filter(product => {
                const productName = product.dataset.name.toLowerCase();
                return productName.includes(searchTerm);
            });

            // Update the display based on the matching products
            updateProductDisplay(matchingProducts);

            // Show or hide the "No items found" message
            noItemsFoundMessage.style.display = matchingProducts.length === 0 ? 'block' : 'none';
        });

// Function to update the display based on the matching products
function updateProductDisplay(matchingProducts) {
    products.forEach(product => {
        const displayStyle = matchingProducts.includes(product) ? 'flex' : 'none';
        product.style.display = displayStyle;

        // If the product is displayed, reset its style to default (block)
        if (displayStyle === 'flex') {
            product.style.width = '';
            product.style.margin = '';
        }
    });
}

    });
</script>


<!-- Add the following script just before the closing </body> tag -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Show loader on form submission
        document.getElementById('loaderContainer').style.display = 'flex';

        // Redirect to login.php after a delay (adjust as needed)
        setTimeout(function () {
           document.getElementById('loaderContainer').style.display = 'none';
        }, 1000); // Redirect after 1 second (1000 milliseconds)
    });
    
    
    
</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const products = document.querySelectorAll('.product');
        const selectedItemsContainer = document.querySelector('.bill-products');

        // Function to update the total amount in the modal
        function updateTotalAmount() {
            const totalAmountContainer = document.getElementById('totalAmount');
            const selectedProducts = document.querySelectorAll('.selected-product');

            let totalAmount = 0;

            selectedProducts.forEach(product => {
                const index = product.dataset.index;
                const originalProduct = document.querySelector(`.product[data-index="${index}"]`);

                if (originalProduct) {
                    const price = parseFloat(originalProduct.dataset.price);
                    const quantityInput = product.querySelector('.selected-product-quantity-input');
                    const quantity = parseInt(quantityInput.value);
                    totalAmount += price * quantity;
                }
            });

            totalAmountContainer.textContent = `₱${totalAmount.toFixed(2)}`;
        }

        // Update the event listener to handle increasing quantity and adding remove button
         products.forEach(product => {
            product.addEventListener('click', () => {
                const index = product.dataset.index;
                const name = product.dataset.name;
                const value = parseFloat(product.dataset.value);
                let quantity = parseInt(product.dataset.quantity);

                if (quantity > 0) {
                    const selectedProduct = document.querySelector(`.selected-product[data-index="${index}"]`);

                    if (selectedProduct) {
                        // Item is already selected, increment quantity
                        const quantityInput = selectedProduct.querySelector('.selected-product-quantity-input');
                        quantityInput.value = parseInt(quantityInput.value) + 1;
                        quantity = parseInt(quantityInput.value);
                    } else {
                        // Item is not selected yet, create a new entry
                        const selectedProduct = document.createElement('div');
                        selectedProduct.classList.add('selected-product');
                        selectedProduct.dataset.index = index;
                        selectedProduct.innerHTML = `
                            <span class="selected-product-info">
                                ${name} - ₱${value.toFixed(2)}
                            </span>
                            <input type="number" class="selected-product-quantity-input" name="product_quantity[${index}]" min="1" value="1">
                            <button class="remove-product" data-index="${index}">Remove</button>
                        `;
                        selectedItemsContainer.appendChild(selectedProduct);

                        const quantityInput = selectedProduct.querySelector('.selected-product-quantity-input');
                        quantityInput.addEventListener('input', () => {
                            quantity = parseInt(quantityInput.value);
                            updateTotalAmount();
                        });

                        const removeButton = selectedProduct.querySelector('.remove-product');
                        removeButton.addEventListener('click', () => {
                            selectedProduct.remove();
                            // Increase the available quantity in the dataset when removing
                            product.dataset.quantity = quantity + 1;
                            updateTotalAmount();
                        });

                        // Update the event listener to handle removing products from the selected items list
removeButton.addEventListener('click', () => {
    selectedProduct.remove();

    // Update the hidden input field (#products) by excluding the removed product ID
    const removedProductId = selectedProduct.dataset.index;
    const productsInput = document.querySelector('section.bill #products');
    const productIds = productsInput.value.split(',');
    const updatedProductIds = productIds.filter(id => id !== removedProductId);
    productsInput.value = updatedProductIds.join(',');

    // Increase the available quantity in the dataset when removing
    product.dataset.quantity = quantity + 1;
    updateTotalAmount();
});

                    }

                    // Update the remaining quantity in the dataset
                    product.dataset.quantity = quantity - 1;

                    let productsInput = document.querySelector('section.bill #products');
                    if (productsInput.value === '') {
                        productsInput.value += index;
                    } else {
                        productsInput.value += ',' + index;
                    }
                }
                updateTotalAmount();
            });
        });
    });
</script>


<script>
    document.addEventListener('DOMContentLoaded', function () {
        const checkoutButton = document.querySelector('.checkout button');
        const paymentModal = document.querySelector('.payment-modal');
        const paymentForm = document.querySelector('.payment-form');
        const paymentMethodSelect = document.querySelector('#payment-method');
        const amountInput = document.querySelector('#amount');
        const closeModalButton = document.querySelector('.close-modal');

        // Disable the proceed button in the modal by default
        const proceedButton = document.querySelector('.payment-form button');
        proceedButton.disabled = true;

        // Create a container for QR codes
        const qrCodeContainer = document.createElement('div');
        qrCodeContainer.classList.add('qr-code-container');
        document.querySelector('.payment-modal-content').appendChild(qrCodeContainer);

        // Event listener for payment method select
        paymentMethodSelect.addEventListener('change', function () {
            displayQRCode();
            toggleAmountInput();
            document.getElementById('paymentMethodInput').value = paymentMethodSelect.value;
        });

        // Event listener for amount input
        amountInput.addEventListener('input', function () {
            toggleProceedButton(); // Enable/disable the proceed button based on the input
        });

        // Event listener for checkout button
        checkoutButton.addEventListener('click', function (event) {
            event.preventDefault();
            openPaymentModal();
        });

        // Event listener for payment method select
        paymentMethodSelect.addEventListener('change', function () {
            toggleAmountInput();
        });

        // Event listener for proceed button in the payment modal
        paymentForm.addEventListener('submit', function (event) {
            event.preventDefault();
            document.getElementById('amountPaidInput').value = amountInput.value;

            // Check if the amount paid is greater than or equal to the total amount
            const totalAmount = parseFloat(document.getElementById('totalAmount').textContent.replace('₱', ''));
            const amountPaid = parseFloat(amountInput.value);

            if (amountPaid >= totalAmount) {
                proceedToBill();
            } else {
                alert('Amount paid must be greater than or equal to the total amount.');
            }
        });

        // Event listener for close button in the payment modal
        closeModalButton.addEventListener('click', function (event) {
            event.preventDefault();
            closePaymentModal();
        });

        function openPaymentModal() {
            paymentModal.style.display = 'block';
        }

        function closePaymentModal() {
            paymentModal.style.display = 'none';
        }

        function toggleProceedButton() {
            // Enable the proceed button in the modal only if the amount input is greater than or equal to the total amount
            const totalAmount = parseFloat(document.getElementById('totalAmount').textContent.replace('₱', ''));
            const amountPaid = parseFloat(amountInput.value);

            proceedButton.disabled = !(amountPaid >= totalAmount);
            
                // Get the reference to the invalid amount element
    const invalidAmountElement = document.getElementById('invalidAmount');

    // Hide the "Invalid amount" text if the proceed button is enabled
    invalidAmountElement.style.display = proceedButton.disabled ? 'block' : 'none';
        }

        function toggleAmountInput() {
            const selectedMethod = paymentMethodSelect.value;
        }

        function proceedToBill() {
            // You may want to add validation for the entered amount here
            // For simplicity, assuming the amount is valid
            closePaymentModal();
            document.querySelector('form').submit();
        }

        function displayQRCode() {
            const selectedMethod = paymentMethodSelect.value;

            // Hide any previous QR codes
            qrCodeContainer.innerHTML = '';

            // Display QR code based on the selected payment method
            if (selectedMethod === 'Gcash') {
                const gcashQRCode = createQRCodeImage('images/qr_gcash.png');
                qrCodeContainer.appendChild(gcashQRCode);
            } else if (selectedMethod === 'Maya') {
                const mayaQRCode = createQRCodeImage('images/qr_maya.png');
                qrCodeContainer.appendChild(mayaQRCode);
            } else {
                // No QR code for cash payment, you can customize this part if needed
                qrCodeContainer.innerHTML = '<p>Pay Cash to Cashier</p>';
            }
        }

        function createQRCodeImage(src) {
            const qrCodeImage = document.createElement('img');
            qrCodeImage.src = src;
            qrCodeImage.width = 500; // Set the desired width
            qrCodeImage.height = 500; // Set the desired height
            qrCodeImage.style.display = 'block'; // Ensure it's a block-level element
            qrCodeImage.style.margin = 'auto'; // Center horizontally
            qrCodeImage.style.marginTop = '20px'; // Add some top margin if needed
            return qrCodeImage;
        }
    });
</script>





</body>
</html>