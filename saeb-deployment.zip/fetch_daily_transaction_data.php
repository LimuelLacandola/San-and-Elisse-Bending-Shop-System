<?php
// fetch_daily_transaction_data.php

// Database connection
require_once 'db_connection.php';

// Fetch daily sales data from the transaction_history table
$dailySalesQuery = "SELECT DATE(transaction_date) AS date, SUM(total_price) AS daily_sales_sum
                    FROM transaction_history
                    WHERE DATE(transaction_date) >= DATE_SUB(CURDATE(), INTERVAL 5 DAY)
                    GROUP BY DATE(transaction_date)
                    ORDER BY DATE(transaction_date)";
$dailySalesResult = $conn->query($dailySalesQuery);

$dates = [];
$dailySalesData = [];

while ($row = $dailySalesResult->fetch_assoc()) {
    $dates[] = $row['date'];
    $dailySalesData[] = $row['daily_sales_sum'];
}

// Close the database connection
$conn->close();

// Return data as JSON
echo json_encode(['dates' => $dates, 'dailySalesData' => $dailySalesData]);
?>
