<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'db_connection.php';

$totalProducts = 0;
$lowStockItems = [];

// Retrieve user information from the login table based on the username
$sql = "SELECT id, user_image, fullname, username, user_role FROM login WHERE username = '{$_SESSION['username']}'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch the user data
    $userData = $result->fetch_assoc();
} else {
    echo "User not found";
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" href="https://z-p3-scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/397997179_250856261335004_614763989636093522_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFAQHoVlJwD-o722MTZbqjNdAN0zl-EgQB0A3TOX4SBAHo4-7I3jVCp1ZpSpzk8h8rreNXwovhcMiIAX8vJlzwe&_nc_ohc=UQ2ASeBN5AcAX9ZRE0z&_nc_oc=AQkjY3_LMBhKeGNlIaHR_Lkk6QJundYBnfwKzhTqTuJifJSEJ47zDdUHEIXCOTu3qVgB3xJC2qq1RDl9iBC9HN8c&_nc_ht=z-p3-scontent.fmnl33-3.fna&oh=03_AdQQX55ul_5PZ8nuIHCCl3WQJaXGzIyLZjsylDCapniYLw&oe=65869B24" type="image/x-icon">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Transaction History</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

        body {
            margin: 0;
            display: flex;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            -moz-transform: scale(0.75, 0.75); /* Moz-browsers */
             zoom: 0.75; /* Other non-webkit browsers */
              zoom: 75%; /* Webkit browsers */
        }

        .content {
            flex: 1;
            padding: 20px;
            
        }
        
  .navigation {
            background-color: #333;
            color: #fff;
            width: 250px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            transition: width 0.5s ease; /* Add transition for smoother resizing */

            
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            padding: 10px; /* Add padding for better hover effect */
    border-radius: 8px; /* Add border radius */
    transition: background-color 0.3s ease, color 0.3s ease; /* Add transitions for background and text color */
        }
        
        .navigation a:not(:last-child) {
            margin-bottom: 10px;
        }
        .navigation a:hover {
                background-color: #cccccc; /* Change background color on hover */
    color: #333; /* Change text color on hover */
    text-decoration: none; /* Remove underline on hover */
        }
        
        .navigation i {
    margin-right: 10px; /* Adjust the space between icon and text */
        vertical-align: middle; /* Align the icon vertically in the middle */
        margin-bottom: 8px;

}

        table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 8px !important;
            /* Add rounded borders to the table */
            margin-top: 20px;
            /* Add some space above the table */
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        #searchBox {
            border: 2px solid transparent;
            width: 15em;
            height: 2.5em;
            padding-left: 0.8em;
            outline: none;
            overflow: hidden;
            background-color: #F3F3F3;
            border-radius: 10px;
            transition: all 0.5s;
        }

        #searchBox:hover,
        #searchBox:focus {
            border: 2px solid #333;
            box-shadow: 0px 0px 0px 7px rgb(102, 102, 102, 20%);
            background-color: white;
        }

        .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            display: none;
        }

        .loader {
            --dim: 3rem;
            width: var(--dim);
            height: var(--dim);
            position: relative;
            animation: spin988 2s linear infinite;
        }

        .loader .circle {
            --color: #333;
            --dim: 1.2rem;
            width: var(--dim);
            height: var(--dim);
            background-color: var(--color);
            border-radius: 50%;
            position: absolute;
        }

        .loader .circle:nth-child(1) {
            top: 0;
            left: 0;
        }

        .loader .circle:nth-child(2) {
            top: 0;
            right: 0;
        }

        .loader .circle:nth-child(3) {
            bottom: 0;
            left: 0;
        }

        .loader .circle:nth-child(4) {
            bottom: 0;
            right: 0;
        }

        @keyframes spin988 {
            0% {
                transform: scale(1) rotate(0);
            }

            20%, 25% {
                transform: scale(1.3) rotate(90deg);
            }

            45%, 50% {
                transform: scale(1) rotate(180deg);
            }

            70%, 75% {
                transform: scale(1.3) rotate(270deg);
            }

            95%, 100% {
                transform: scale(1) rotate(360deg);
            }
        }

        .user-info {
            margin-top: auto;
            display: flex;
            align-items: center;
            text-decoration: none;
            /* Remove underline from the link */
            color: #fff;
        }

        .user-info img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 50%;
        }

        #logoLink img {
        width: 250px; /* Adjust the width as needed */
        height: auto; /* Maintains the aspect ratio */
        margin-bottom: -10px; /* Adjust this value to fine-tune the alignment */
        margin-left: -52px;
    }
    
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
    background-color: #fefefe;
    margin: 5% auto; /* Adjusted the top margin to 5% */
    padding: 20px;
    border: 1px solid #888;
    width: 50%;
    border-radius: 10px;
    text-align: center;
}




       .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
    </style>
</head>
<body>
<div class="loader-container" id="loaderContainer">
    <div class="loader">
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
        <div class="circle"></div>
    </div>
</div>

<div class="navigation">
    <a href="index.php" id="logoLink">
        <img src="images/saebs_logo.png" alt="Logo">
    </a>
    <a href="index.php"><i class="material-icons">home</i> Home</a>
    <a href="inventory.php"><i class="material-icons">handyman</i> Inventory</a>
    <a href="notification.php"><i class="material-icons">notifications</i>Notifications</a>

    <a href="pos.php"><i class="material-icons">point_of_sale</i> Point of Sale</a>
    <!-- <a href="sales_report.php"><i class="material-icons">insert_chart_outlined</i> Sales Report</a> -->
    <a href="transaction_history.php"><i class="material-icons">receipt_long</i> Transaction History</a>
    <a href="refund.php"><i class="material-icons">history</i> Refund</a>


    <?php
    if ($_SESSION['user_role'] === 'admin') {
        echo '<a href="employee_list.php"><i class="material-icons">groups</i> Employee List</a>';
        echo '<a href="restock.php"><i class="material-icons">inventory</i> Restock</a>';
        echo '<a href="supplier.php"><i class="material-icons">local_shipping</i> Supplier</a>';
        echo '<a href="view_sessions.php"><i class="material-icons">access_time</i> Sessions</a>';
        
    } elseif ($_SESSION['user_role'] === 'employee') {
        // Employee can only access limited features
    } else {
        echo "Invalid user role.";
    }
    ?>
    
    <a href="restock_history.php"><i class="material-icons">manage_history</i> Restock History</a>
    <a href="logout.php" id="logoutLink"><i class="material-icons">logout</i> Logout</a>

    <?php
    // Check if the user has a custom image, otherwise, display a default image
    $userImage = isset($userData["user_image"]) ? $userData["user_image"] : "path/to/default-image.png";
    ?>
    <a href="user_info.php" class="user-info">
        <img src="<?php echo $userImage; ?>" alt="User Image">
    </a>
</div>

<div class="content">
    <h2>Transaction History</h2>
    <input type="text" id="searchBox" placeholder="Search items">
    <div id="transactionTable"></div>
</div>

<!-- Modal HTML structure -->
<div id="itemModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <div id="modalContent"></div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function () {
    const transactionTable = document.getElementById('transactionTable');

    // Function to open the modal and load transaction details
    function openModal(itemId) {
        fetch(`fetch_transaction_details.php?id=${itemId}`)
            .then(response => response.text())
            .then(data => {
                document.getElementById('modalContent').innerHTML = data;
                document.getElementById('itemModal').style.display = 'block';
            })
            .catch(error => {
                console.error('Error fetching transaction details:', error);
            });
    }

    // Function to close the modal
    function closeModal() {
        const modalContent = document.getElementById('modalContent');
        // Additional actions to perform before closing the modal
        // For example, clear the modal content
        modalContent.innerHTML = '';
        document.getElementById('itemModal').style.display = 'none';
    }

    // Close the modal if the user clicks outside of it
    window.onclick = function (event) {
        if (event.target == document.getElementById('itemModal')) {
            closeModal();
        }
    };

    // Use event delegation on the parent container
    transactionTable.addEventListener('click', function (event) {
        const target = event.target;
        if (target.tagName === 'TD') {
            const itemId = target.closest('tr').querySelector('td:first-child').textContent;
            openModal(itemId);
        }
    });

    // Function to update the transaction history table with pagination
    function updateTransactionHistory(searchTerm, page) {
        // Show loader on form submission
        document.getElementById('loaderContainer').style.display = 'flex';

        // Send an AJAX request to fetch transaction data with the search term and page
        fetch(`fetch_transaction_history.php?search=${searchTerm}&page=${page}`)
            .then(response => response.text())
            .then(data => {
                transactionTable.innerHTML = data;
            })
            .catch(error => {
                console.error('Error fetching transaction data:', error);
            })
            .finally(() => {
                // Hide loader
                document.getElementById('loaderContainer').style.display = 'none';
            });
    }

    // Function to handle search box input
    document.getElementById('searchBox').addEventListener('input', function () {
        const searchTerm = this.value.toLowerCase().trim();
        currentPage = 1; // Reset to the first page when searching
        updateTransactionHistory(searchTerm, currentPage);
    });

    // Initial table update without search term
    updateTransactionHistory('', currentPage);
});




</script>



<!-- Add the following script just before the closing </body> tag -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Show loader on form submission
        document.getElementById('loaderContainer').style.display = 'flex';

        // Redirect to login.php after a delay (adjust as needed)
        setTimeout(function () {
            document.getElementById('loaderContainer').style.display = 'none';
        }, 1000); // Redirect after 1 second (1000 milliseconds)
    });

    let currentPage = 1; // Current page
    const itemsPerPage = 13; // Number of items per page

    // Function to update the transaction history table with pagination
    function updateTransactionHistory(searchTerm, page) {
        const transactionTable = document.getElementById('transactionTable');

        // Send an AJAX request to fetch transaction data with the search term and page
        fetch(`fetch_transaction_history.php?search=${searchTerm}&page=${page}`)
            .then(response => response.text())
            .then(data => {
                transactionTable.innerHTML = data;
            })
            .catch(error => {
                console.error('Error fetching transaction data:', error);
            });
    }

    // Function to handle search box input
    document.getElementById('searchBox').addEventListener('input', function () {
        const searchTerm = this.value.toLowerCase().trim();
        currentPage = 1; // Reset to the first page when searching
        updateTransactionHistory(searchTerm, currentPage);
    });

    // Initial table update without search term
    updateTransactionHistory('', currentPage);
</script>

</body>
</html>
