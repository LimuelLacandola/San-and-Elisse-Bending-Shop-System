<?php


date_default_timezone_set('Asia/Manila');

// Start a session
session_start();

// Database connection
require_once 'db_connection.php';

// Include SweetAlert CDN links
echo '
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel = "icon" href = "https://z-p3-scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/397997179_250856261335004_614763989636093522_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFAQHoVlJwD-o722MTZbqjNdAN0zl-EgQB0A3TOX4SBAHo4-7I3jVCp1ZpSpzk8h8rreNXwovhcMiIAX8vJlzwe&_nc_ohc=UQ2ASeBN5AcAX9ZRE0z&_nc_oc=AQkjY3_LMBhKeGNlIaHR_Lkk6QJundYBnfwKzhTqTuJifJSEJ47zDdUHEIXCOTu3qVgB3xJC2qq1RDl9iBC9HN8c&_nc_ht=z-p3-scontent.fmnl33-3.fna&oh=03_AdQQX55ul_5PZ8nuIHCCl3WQJaXGzIyLZjsylDCapniYLw&oe=65869B24" 
        type = "image/x-icon"> 
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <meta charset="UTF-8">
    <title>Login</title>
</head>
<body>';

// Process login form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Fetch the user's data from the login table
    $query = "SELECT * FROM login WHERE username=?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $hashedPassword = $row['password'];

        // Verify the password using password_verify
        if (password_verify($password, $hashedPassword)) {
            // Login successful
            $_SESSION['username'] = $row['username'];
            $_SESSION['user_role'] = $row['user_role'];
            $fullname = $row['fullname'];

            date_default_timezone_set('Asia/Manila');
            $loginTime = date('Y-m-d H:i:s');

            // Add login information to the log table
            $logQuery = "INSERT INTO log (username, fullname, login_time) VALUES (?, ?, ?)";
            $logStmt = $conn->prepare($logQuery);
            $logStmt->bind_param('sss', $username, $fullname, $loginTime);
            $logStmt->execute();
            $logStmt->close();

            // Redirect to appropriate page based on the user's role
            echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Login Successful',
                    text: 'Welcome, $fullname!',
                }).then(() => {
                    window.location = 'index.php';
                });
            </script>";
        } else {
            // Login failed
            echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Login Failed',
                    text: 'Invalid username or password',
                });
            </script>";
        }
    } else {
        // Login failed
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Login Failed',
                text: 'Invalid username or password',
            });
        </script>";
    }
}

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" href="/images/saebs_logo.png" type="image/x-icon">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <meta charset="UTF-8">
    <title>Login</title>

    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

        body {
            background: url('images/loginbg.jpg') center/cover no-repeat fixed;
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            font-family: 'Poppins', sans-serif;
            color: #333333;
            margin: 0;
            padding: 0;
            overflow: hidden;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }

        .card {
            width: 60%;
            background: #FFFFFF;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 0 20px 6px #6f6f6f;
            padding: 20px;
            box-sizing: border-box;
            display: flex;
            flex-direction: row;
        }

.left-section {
    flex: 1;
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: start;
    justify-content: flex-start;
    text-align: left;
}
        .right-section {
            flex: 1;
            padding: 20px;

        }

        .logo {
        max-width: 150px;
        max-height: 500px;
    
            
        }

        .text-container {
            max-width: 300px;
            margin-bottom: 20px;
            text-align: left;
        }

        .box-form {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .box-form h5 {
            font-size: 5vmax;
            line-height: 0;
        }

        .box-form .inputs {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .box-form input {
            width: 100%;
            padding: 15px;
            margin-top: 15px;
            font-size: 16px;
            border: none;
            outline: none;
            border-radius: 5px;
            border: 2px solid #B0B3B9;
            background-color: #f8fafc;
            transition: border-color 0.3s, background-color 0.3s;
        }

        .box-form input::placeholder {
            color: #94a3b8;
        }

        .box-form input:focus, .box-form input:hover {
            border-color: rgba(111, 111, 111);
            background-color: #fff;
        }

        .box-form button {
            background: #333;
            color: #fff;
            font-size: 16px;
            font-family: 'Poppins', sans-serif;
            padding: 10px 75px;
            border-radius: 10px;
            border: 0;
            outline: 0;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-left: 35px;
            margin-top: 20px;
         
        }

        .box-form button:hover {
            background-color: #333;
        }
.text-container h5 {
    font-size: 3vmax;
    font-weight: bold; /* Explicitly set font weight to bold */
}

        .text-container h4 {
    font-size: 20px; /* Adjust the size as needed */
    margin: 0;

}

.box-form label {
    margin-top: 15px;
    margin-right: 10px;
}

.eye-icon-container {
    position: absolute;
    top: 65%;
    right: -10px;
    transform: translateY(-50%);
    cursor: pointer;
}

.eye-icon {
    width: 24px; /* Adjust the width as needed */
    height: 24px; /* Adjust the height as needed */
    transition: opacity 0.3s;
}

.eye-icon:hover {
    opacity: 0.7;
}

    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="left-section">
                <img class="logo" src="images/saebs_logo.png" alt="Store Logo">
                <div class="text-container">
                    <h5>Welcome to San and Elisse Bending Shop</h5>
                    <h4>Cabuyao, Laguna</h4>
                    <h4>+63 912 3456 789</h4>
                </div>
            </div>
            <div class="right-section">
<div class="box-form">
    <h5>Login</h5>
    <div class="inputs">
        <form action="login.php" method="post">
            <input type="text" id="username" name="username" placeholder="Username" required><br>
            <div style="position: relative;">
                <input type="password" id="password" name="password" placeholder="Password" required>
                <span id="eyeIcon" class="eye-icon-container">
        <img id="closedEye" class="eye-icon" src="images/hide.png" alt="Closed Eye">
        <img id="openEye" class="eye-icon" src="images/show.png" alt="Open Eye" style="display: none;">
    </span>
            </div>
            <center><button>LOG IN</button></center>
        </form>
    </div>
</div>
            </div>
        </div>
    </div>
    <<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Get the input field for the password
        const passwordInput = document.getElementById('password');
        // Get the eye icons
        const openEyeIcon = document.getElementById('openEye');
        const closedEyeIcon = document.getElementById('closedEye');
        // Get the eye icon container
        const eyeIconContainer = document.getElementById('eyeIcon');

        // Add an event listener to the eye icon container
        eyeIconContainer.addEventListener('click', function () {
            // Toggle the visibility of the eye icons
            openEyeIcon.style.display = openEyeIcon.style.display === 'none' ? 'block' : 'none';
            closedEyeIcon.style.display = closedEyeIcon.style.display === 'none' ? 'block' : 'none';

            // Change the type attribute of the password input based on eye icon visibility
            passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
        });
    });
</script>
</body>
</html>