<?php
require_once 'db_connection.php';

if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    // Prepare and execute the SQL query to delete the product
    $query = "DELETE FROM inventory WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $productId);
    
    if ($stmt->execute()) {
        echo 'Product deleted successfully.';
    } else {
        echo 'Error deleting product.';
    }

    $stmt->close();
} else {
    echo 'Product ID not provided.';
}

$conn->close();
?>
