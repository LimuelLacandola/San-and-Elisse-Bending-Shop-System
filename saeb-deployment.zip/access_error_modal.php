<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Error Modal</title>
    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 999;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            text-align: center;
        }

        .modal-button {
            margin-top: 10px;
            padding: 5px 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div id="errorModal" class="modal">
        <div class="modal-content">
		<h1>Admin Feature!</h1>
            <p>Access denied. You do not have permission to access this page.</p>
            <button id="goBackButton" class="modal-button">Go Back</button>
        </div>
    </div>

    <script>
        // JavaScript to show the modal and handle the "Go Back" button click
        const errorModal = document.getElementById('errorModal');
        const goBackButton = document.getElementById('goBackButton');

        goBackButton.addEventListener('click', () => {
            errorModal.style.display = 'none';
            window.history.back(); // Go back to the previous page
        });

        // Show the modal when the page loads
        errorModal.style.display = 'block';
    </script>
</body>
</html>
