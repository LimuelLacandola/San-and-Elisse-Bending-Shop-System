<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}


require_once 'db_connection.php';

$productId = $_GET['id'];

// Prepare and execute the SQL query to fetch product information by ID
$query = "SELECT * FROM inventory WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $productId);
$stmt->execute();
$result = $stmt->get_result();

// Display product information in the modal
if ($result->num_rows > 0) {
    $product = $result->fetch_assoc();
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Product Information</title>
        
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');
            

            .flex {
                display: flex;
                gap: 10px;
                justify-content: center;
            }

            .editButton, .deleteButton {
                padding: 10px;
                background-color: #333;
                color: #fff;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                transition: background-color 0.3s;
            }

            .editButton:hover, .deleteButton:hover {
                background-color: #555;
            }
        </style>
    </head>
    <body>
        <h2 class="title">Product Information</h2>
        <p><strong>Product Name:</strong> <?= $product['productname'] ?></p>
        <p><strong>Brand:</strong> <?= $product['brand'] ?></p>
        <p><strong>Category:</strong> <?= $product['category'] ?></p>
        <p><strong>Description:</strong> <?= $product['description'] ?></p>
        <p><strong>Quantity:</strong> <?= $product['quantity'] ?></p>
        <p><strong>Measurement:</strong> <?= $product['measurement'] ?></p>
        <p><strong>Price:</strong> <?= $product['price'] ?></p>
        <p><strong>Supplier Name:</strong> <?= $product['supplier_name'] ?></p>
        <p><strong>Supplier Email:</strong> <?= $product['supplier_email'] ?></p>
        <p><strong>Image:</strong> <br><img src="<?= $product['image_url'] ?>" alt="Product Image" style="max-width: 100px;"></p>


<?php
if ($_SESSION['user_role'] === 'admin') {
    echo '<div class="flex">';
    echo '<button class="editButton" data-product-id="' . $product['id'] . '">Update</button>';
    echo '<button class="deleteButton" onclick="deleteProduct(' . $productId . ')">Delete</button>';
    echo '</div>';
} elseif ($_SESSION['user_role'] === 'employee') {
    // No action for employees (you can add specific employee logic here)
} else {
    echo "Invalid user role.";
}
?>





    </body>
    </html>

    <?php
} else {
    echo 'Product not found.';
}

$stmt->close();
$conn->close();