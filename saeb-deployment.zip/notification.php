<?php
session_start();

// Redirect to login page if not logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Database connection
require_once 'db_connection.php';

// Retrieve user information
function getUserData($conn) {
    $stmt = $conn->prepare("SELECT id, user_image, fullname, username, user_role FROM login WHERE username = ?");
    $stmt->bind_param("s", $_SESSION['username']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        return $result->fetch_assoc();
    } else {
        echo "User not found";
        return null;
    }
}

$userData = getUserData($conn);

// Retrieve low stock and danger items in a single query
function getLowDangerItems($conn, $lowStockThreshold, $dangerThreshold) {
    $stmt = $conn->prepare("SELECT * FROM inventory WHERE quantity <= ? OR quantity <= ?");
    $stmt->bind_param("ii", $lowStockThreshold, $dangerThreshold);
    $stmt->execute();
    $result = $stmt->get_result();

    $lowStockItems = [];
    $dangerItems = [];

    while ($row = $result->fetch_assoc()) {
        if ($row['quantity'] <= $lowStockThreshold) {
            $lowStockItems[] = $row;
        } elseif ($row['quantity'] <= $dangerThreshold) {
            $dangerItems[] = $row;
        }
    }

    return ['lowStockItems' => $lowStockItems, 'dangerItems' => $dangerItems];
}

$thresholds = ['lowStock' => 20, 'danger' => 50];
$items = getLowDangerItems($conn, $thresholds['lowStock'], $thresholds['danger']);
$lowStockItems = $items['lowStockItems'];
$dangerItems = $items['dangerItems'];

// Function to insert notification into notification_history
function insertNotification($conn, $type, $productName, $quantity, $userTriggered) {
    // Check if a similar notification already exists
    $stmt = $conn->prepare("SELECT * FROM notification_history WHERE type = ? AND product_name = ? AND quantity = ?");
    $stmt->bind_param("ssi", $type, $productName, $quantity);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        // Insert the notification only if it doesn't exist
        $notificationDate = date('Y-m-d H:i:s');
        $stmt = $conn->prepare("INSERT INTO notification_history (type, product_name, quantity, notification_date, user_triggered) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssiss", $type, $productName, $quantity, $notificationDate, $userTriggered);

        if ($stmt->execute() !== TRUE) {
            echo "Error inserting record into notification_history: " . $stmt->error;
        }
    }
}

// Save low stock notifications
foreach ($lowStockItems as $item) {
    insertNotification($conn, 'Low Stock', $item['productname'], $item['quantity'], $_SESSION['username']);
}

// Save danger notifications
foreach ($dangerItems as $item) {
    insertNotification($conn, 'Danger', $item['productname'], $item['quantity'], $_SESSION['username']);
}

// Fetch restock notifications
$sqlRestockNotifications = "SELECT * FROM notification_history WHERE type = 'restock' AND MONTH(notification_date) = MONTH(CURRENT_DATE()) AND YEAR(notification_date) = YEAR(CURRENT_DATE()) ORDER BY notification_date DESC";
$resultRestockNotifications = $conn->query($sqlRestockNotifications);

$conn->close();
?>
<!DOCTYPE html>
<html>
<head>
    
    <link rel = "icon" href =  
"https://z-p3-scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/397997179_250856261335004_614763989636093522_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFAQHoVlJwD-o722MTZbqjNdAN0zl-EgQB0A3TOX4SBAHo4-7I3jVCp1ZpSpzk8h8rreNXwovhcMiIAX8vJlzwe&_nc_ohc=UQ2ASeBN5AcAX9ZRE0z&_nc_oc=AQkjY3_LMBhKeGNlIaHR_Lkk6QJundYBnfwKzhTqTuJifJSEJ47zDdUHEIXCOTu3qVgB3xJC2qq1RDl9iBC9HN8c&_nc_ht=z-p3-scontent.fmnl33-3.fna&oh=03_AdQQX55ul_5PZ8nuIHCCl3WQJaXGzIyLZjsylDCapniYLw&oe=65869B24" 
        type = "image/x-icon"> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <title>Notification</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');
        body {
            margin: 0;
            display: flex;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            -moz-transform: scale(0.75, 0.75); /* Moz-browsers */
             zoom: 0.75; /* Other non-webkit browsers */
              zoom: 75%; /* Webkit browsers */
            
        }
        
        .content {
            flex: 1;
            padding: 20px;
            
        }
        
        .navigation {
            background-color: #333;
            color: #fff;
            width: 250px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            transition: width 0.5s ease; /* Add transition for smoother resizing */

            
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            padding: 10px; /* Add padding for better hover effect */
    border-radius: 8px; /* Add border radius */
    transition: background-color 0.3s ease, color 0.3s ease; /* Add transitions for background and text color */
        }
        
        .navigation a:not(:last-child) {
            margin-bottom: 10px;
        }
        .navigation a:hover {
                background-color: #cccccc; /* Change background color on hover */
    color: #333; /* Change text color on hover */
    text-decoration: none; /* Remove underline on hover */
        }
        
        .navigation i {
    margin-right: 10px; /* Adjust the space between icon and text */
        vertical-align: middle; /* Align the icon vertically in the middle */
        margin-bottom: 8px;

}
                .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            display: none;
        }

.loader {
  --dim: 3rem;
  width: var(--dim);
  height: var(--dim);
  position: relative;
  animation: spin988 2s linear infinite;
}

.loader .circle {
  --color: #333;
  --dim: 1.2rem;
  width: var(--dim);
  height: var(--dim);
  background-color: var(--color);
  border-radius: 50%;
  position: absolute;
}

.loader .circle:nth-child(1) {
  top: 0;
  left: 0;
}

.loader .circle:nth-child(2) {
  top: 0;
  right: 0;
}

.loader .circle:nth-child(3) {
  bottom: 0;
  left: 0;
}

.loader .circle:nth-child(4) {
  bottom: 0;
  right: 0;
}

@keyframes spin988 {
  0% {
    transform: scale(1) rotate(0);
  }

  20%, 25% {
    transform: scale(1.3) rotate(90deg);
  }

  45%, 50% {
    transform: scale(1) rotate(180deg);
  }

  70%, 75% {
    transform: scale(1.3) rotate(270deg);
  }

  95%, 100% {
    transform: scale(1) rotate(360deg);
  }
}


.notification-icon {
    position: fixed;
    top: 10px;
    margin-top: 15px;
    margin-right: 15px;
    right: calc(10px + 30px + 10px); /* Adjust margin as needed */
    font-size: 24px; /* Adjust font size as needed */
    color: black; /* Adjust icon color as needed */
    cursor: pointer; /* Optional: add a pointer cursor for better UX */
}

    .user-info img {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-left: -10px; /* Adjust the negative margin to make it overlap */
    }
        
            #logoLink img {
        width: 250px; /* Adjust the width as needed */
        height: auto; /* Maintains the aspect ratio */
        margin-bottom: -10px; /* Adjust this value to fine-tune the alignment */
        margin-left: -52px;
    }
    
       #chartCard {
            width: 450px; /* Adjust the width as needed to make it bigger than other cards */
            margin: 40px;
        }


        .notification {
            padding: 10px;
            background-color: #fde0e0; /* Adjust the color as needed */
            margin-bottom: 10px;
            border-radius: 5px;
            position: relative;
                  padding: 10px;
            border: 1px solid #ddd;
      
        }
        
        .notification .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            cursor: pointer;
            font-size: 16px;
            color: #555;
            font-weight: bold;
            background-color: transparent;
            border: none;
            outline: none;
            padding: 0;
        }

        .notification .close-btn:hover {
            color: #000;
        }

.danger-orange {
    background-color: #fedd9e; /* Adjust the orange color as needed */
    color: #333; /* Adjust text color for visibility */
}

    .success {
        background-color: #77dd77; /* Adjust the green color as needed */
        color: #333; /* Adjust text color for visibility */
    }
    
        .notifications-container {
        max-height: 750px; /* Set the maximum height as needed */
        overflow-y: auto; /* Enable vertical scroll when content exceeds the height */
    }
    </style>
</head>

<body>
    
            <div class="loader-container" id="loaderContainer">
        <div class="loader">
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
</div>

    </div>
    
    <div class="navigation">
    <a href="index.php" id="logoLink">
        <img src="images/saebs_logo.png" alt="Logo">
    </a>
    <a href="index.php"><i class="material-icons">home</i> Home</a>
    <a href="inventory.php"><i class="material-icons">handyman</i> Inventory</a>
    <a href="notification.php"><i class="material-icons">notifications</i>Notifications</a>

    <a href="pos.php"><i class="material-icons">point_of_sale</i> Point of Sale</a>
    <!-- <a href="sales_report.php"><i class="material-icons">insert_chart_outlined</i> Sales Report</a> -->
    <a href="transaction_history.php"><i class="material-icons">receipt_long</i> Transaction History</a>
    <a href="refund.php"><i class="material-icons">history</i> Refund</a>


    <?php
    if ($_SESSION['user_role'] === 'admin') {
        echo '<a href="employee_list.php"><i class="material-icons">groups</i> Employee List</a>';
        echo '<a href="restock.php"><i class="material-icons">inventory</i> Restock</a>';
        echo '<a href="supplier.php"><i class="material-icons">local_shipping</i> Supplier</a>';
        echo '<a href="view_sessions.php"><i class="material-icons">access_time</i> Sessions</a>';
        
    } elseif ($_SESSION['user_role'] === 'employee') {
        // Employee can only access limited features
    } else {
        echo "Invalid user role.";
    }
    ?>
    
    <a href="restock_history.php"><i class="material-icons">manage_history</i> Restock History</a>
    <a href="logout.php" id="logoutLink"><i class="material-icons">logout</i> Logout</a>

    <?php
    // Check if the user has a custom image, otherwise, display a default image
    $userImage = isset($userData["user_image"]) ? $userData["user_image"] : "path/to/default-image.png";
    ?>
    <a href="user_info.php" class="user-info">
        <img src="<?php echo $userImage; ?>" alt="User Image">
    </a>
</div>

    <div class="content">
            <div class="notifications-container">



  
        <h2>Notification</h2>
        <?php
        // Display low stock items as notifications
        if (!empty($lowStockItems)) {
            foreach ($lowStockItems as $item) {
                echo '<div class="notification">';
                echo '<span class="close-btn" onclick="dismissNotification(this)">&times;</span>';
                echo '<strong>Low Stock:</strong> ' . $item['productname'] . ' has ' . $item['quantity'] . ' left.';
                echo '</div>';
            }
        } else {
            echo '<p>No low stock items at the moment.</p>';
        }

        // Display danger items as notifications with an orange background
        if (!empty($dangerItems)) {
            foreach ($dangerItems as $item) {
                echo '<div class="notification danger-orange">';
                echo '<span class="close-btn" onclick="dismissNotification(this)">&times;</span>';
                echo '<strong>Danger:</strong> ' . $item['productname'] .' '. $item['quantity'] . ' left.';
                echo '</div>';
            }
        } else {
            echo '<p>No danger items at the moment.</p>';
        }
        
    // Display restock notifications
    if ($resultRestockNotifications->num_rows > 0) {
        foreach ($resultRestockNotifications as $row) {
            echo '<div class="notification"  data-type="restock" style="background-color: #B2FBA5; color: #333;">'; // Set the background color to green
                            echo '<span class="close-btn" onclick="dismissNotification(this)">&times;</span>';

            echo '<strong> Restocked: ' . $row['user_triggered'] . '</strong> restocked <strong>' . $row['product_name'] . '</strong> with a quantity of <strong>' . $row['quantity'] . '</strong> on ' . $row['notification_date'];
            echo '</div>';
        }
    } else {
        echo '<p>No notifications at the moment.</p>';
    }
    ?>
        </div>
        </div>
        
        <script>
    document.addEventListener('DOMContentLoaded', function () {
        // Show loader on form submission
        document.getElementById('loaderContainer').style.display = 'flex';

        // Redirect to login.php after a delay (adjust as needed)
        setTimeout(function () {
           document.getElementById('loaderContainer').style.display = 'none';
        }, 1000); // Redirect after 1 second (1000 milliseconds)
    });
</script>

    <script>
        function dismissNotification(closeBtn) {
            // Hide the parent notification element
            closeBtn.parentElement.style.display = 'none';
        }
    </script>

<script>
        document.addEventListener('DOMContentLoaded', function () {
            // Show loader on form submission
            document.getElementById('loaderContainer').style.display = 'flex';

            // Redirect to login.php after a delay (adjust as needed)
            setTimeout(function () {
                document.getElementById('loaderContainer').style.display = 'none';
            }, 1000); // Redirect after 1 second (1000 milliseconds)

            // Hide restock notifications after 5 minutes
            setTimeout(function () {
                var restockNotifications = document.querySelectorAll('.notification[data-type="restock"]');
                restockNotifications.forEach(function (notification) {
                    notification.style.display = 'none';
                });
            }, 300000); // 5 minutes in milliseconds
        });

        function dismissNotification(closeBtn) {
            // Hide the parent notification element
            closeBtn.parentElement.style.display = 'none';
        }
    </script>
        </body>
</html>