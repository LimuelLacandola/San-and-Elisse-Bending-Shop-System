<?php

function restrictAccessToEmployee($userRole) {
    if ($userRole === 'employee') {
        // If the user is an employee, restrict access
        include 'access_error_modal.php';
        exit();
    }
}
?>

