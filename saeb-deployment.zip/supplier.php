<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("Location: login.php"); // Redirect to login page if not logged in
    exit();
}
require_once 'access_control.php';

$userRole = $_SESSION['user_role'];
restrictAccessToEmployee($userRole);

// Database connection
require_once 'db_connection.php';

// Retrieve user information from the login table based on the username
$sql = "SELECT id, user_image, fullname, username, user_role FROM login WHERE username = '{$_SESSION['username']}'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Fetch the user data
    $userData = $result->fetch_assoc();
} else {
    echo "User not found";
}
?>

<!DOCTYPE html>
<html>
<head>
    <link rel = "icon" href =  
"https://z-p3-scontent.fmnl33-3.fna.fbcdn.net/v/t1.15752-9/397997179_250856261335004_614763989636093522_n.png?_nc_cat=110&ccb=1-7&_nc_sid=8cd0a2&_nc_eui2=AeFAQHoVlJwD-o722MTZbqjNdAN0zl-EgQB0A3TOX4SBAHo4-7I3jVCp1ZpSpzk8h8rreNXwovhcMiIAX8vJlzwe&_nc_ohc=UQ2ASeBN5AcAX9ZRE0z&_nc_oc=AQkjY3_LMBhKeGNlIaHR_Lkk6QJundYBnfwKzhTqTuJifJSEJ47zDdUHEIXCOTu3qVgB3xJC2qq1RDl9iBC9HN8c&_nc_ht=z-p3-scontent.fmnl33-3.fna&oh=03_AdQQX55ul_5PZ8nuIHCCl3WQJaXGzIyLZjsylDCapniYLw&oe=65869B24" 
        type = "image/x-icon"> 
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <title>Supplier Information</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');
        body {
            margin: 0;
            display: flex;
            min-height: 100vh;
            font-family: 'Poppins', sans-serif;
            -moz-transform: scale(0.75, 0.75); /* Moz-browsers */
             zoom: 0.75; /* Other non-webkit browsers */
              zoom: 75%; /* Webkit browsers */
        }
        .content {
            flex: 1;
            padding: 20px;
            
        }
        
  .navigation {
            background-color: #333;
            color: #fff;
            width: 250px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            transition: width 0.5s ease; /* Add transition for smoother resizing */

            
        }

        .navigation a {
            color: #fff;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
            padding: 10px; /* Add padding for better hover effect */
    border-radius: 8px; /* Add border radius */
    transition: background-color 0.3s ease, color 0.3s ease; /* Add transitions for background and text color */
        }
        
        .navigation a:not(:last-child) {
            margin-bottom: 10px;
        }
        .navigation a:hover {
                background-color: #cccccc; /* Change background color on hover */
    color: #333; /* Change text color on hover */
    text-decoration: none; /* Remove underline on hover */
        }
        
        .navigation i {
    margin-right: 10px; /* Adjust the space between icon and text */
        vertical-align: middle; /* Align the icon vertically in the middle */
        margin-bottom: 8px;

}

         table {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 8px !important; /* Add rounded borders to the table */
            margin-top: 20px; /* Add some space above the table */
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ccc;
        }
        th {
            background-color: #f2f2f2;
        }
                tr:hover {
    background-color: #f5f5f5;
}
        
    /* Add styles for the modal */
    
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
    background-color: #fefefe;
    margin: 10% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    border-radius: 10px;
    text-align: center;
}



       .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
/* Center the form within the modal */
form {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.title {
align-items: center;
  font-size: 28px;
  color: #333;
  font-weight: 600;
  letter-spacing: -1px;
  position: relative;
  display: flex;
  align-items: center;
  padding-left: 30px;
justify-content: center; /* Center the title horizontally */

}

.title::before,.title::after {
  position: absolute;
  content: "";
  height: 16px;
  width: 16px;
  border-radius: 50%;
left: 400px; /* Place the pseudo-elements to the left */

  background-color: #333;
  
}

.title::before {
  width: 18px;
  height: 18px;
  background-color: #333;
}

.title::after {
  width: 18px;
  height: 18px;
  animation: pulse 1s linear infinite;
  
}

.flex {
  display: flex;
  width: 100%;
  gap: 6px;
}

.form label {
  position: relative;
  margin-bottom: 10px;

}

.form label .input {
  width: 100%;
  padding: 10px 10px 20px 10px;
  outline: 0;
  border: 1px solid rgba(105, 105, 105, 0.397);
  border-radius: 10px;
}

.form label .input + span {
  position: absolute;
  left: 10px;
  top: 15px;
  color: grey;
  font-size: 0.9em;
  cursor: text;
  transition: 0.3s ease;
}

.form label .input:placeholder-shown + span {
  top: 15px;
  font-size: 0.9em;
}

.form label .input:focus + span,.form label .input:valid + span {
  top: 30px;
  font-size: 0.7em;
  font-weight: 600;
}

.form label .input:valid + span {
  color: #333;
}

.submit {
  border: none;
  outline: none;
  background-color: #333;
  padding: 10px;
  border-radius: 10px;
  color: white;
  font-size: 16px;
  transform: .3s ease;
}

.submit:hover {
  background-color: rgb(56, 90, 194);
}

@keyframes pulse {
  from {
    transform: scale(0.9);
    opacity: 1;
  }

  to {
    transform: scale(1.8);
    opacity: 0;
  }
}
    
    #searchBox {
  border: 2px solid transparent;
  width: 15em;
  height: 2.5em;
  padding-left: 0.8em;
  outline: none;
  overflow: hidden;
  background-color: #F3F3F3;
  border-radius: 10px;
  transition: all 0.5s;
}

#searchBox:hover,
#searchBox:focus {
  border: 2px solid #333;
  box-shadow: 0px 0px 0px 7px rgb(102, 102, 102, 20%);
  background-color: white;
}

.button {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: rgb(20, 20, 20);
  border: none;
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.164);
  cursor: pointer;
  transition-duration: .3s;
  overflow: hidden;
  position: relative;
}

.svgIcon {
  width: 12px;
  transition-duration: .3s;
}

.svgIcon path {
  fill: white;
}

.button:hover {
  width: 140px;
  border-radius: 50px;
  transition-duration: .3s;
  background-color: rgb(255, 69, 69);
  align-items: center;
}



.button::before {
  position: absolute;
  top: -20px;
  content: "Add new supplier";
  color: white;
  transition-duration: .3s;
  font-size: 2px;
}

.button:hover::before {
  font-size: 13px;
  opacity: 1;
  transform: translateY(30px);
  transition-duration: .3s;
}

                .loader-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            display: none;
        }

.loader {
  --dim: 3rem;
  width: var(--dim);
  height: var(--dim);
  position: relative;
  animation: spin988 2s linear infinite;
}

.loader .circle {
  --color: #333;
  --dim: 1.2rem;
  width: var(--dim);
  height: var(--dim);
  background-color: var(--color);
  border-radius: 50%;
  position: absolute;
}

.loader .circle:nth-child(1) {
  top: 0;
  left: 0;
}

.loader .circle:nth-child(2) {
  top: 0;
  right: 0;
}

.loader .circle:nth-child(3) {
  bottom: 0;
  left: 0;
}

.loader .circle:nth-child(4) {
  bottom: 0;
  right: 0;
}

@keyframes spin988 {
  0% {
    transform: scale(1) rotate(0);
  }

  20%, 25% {
    transform: scale(1.3) rotate(90deg);
  }

  45%, 50% {
    transform: scale(1) rotate(180deg);
  }

  70%, 75% {
    transform: scale(1.3) rotate(270deg);
  }

  95%, 100% {
    transform: scale(1) rotate(360deg);
  }
}

        .user-info {
            margin-top: auto;
            display: flex;
            align-items: center;
            text-decoration: none; /* Remove underline from the link */
            color: #fff;
        }

        .user-info img {
            width: 30px;
            height: 30px;
            margin-right: 10px;
            border-radius: 50%;
        }
        
        .table-wrapper {
    max-height: 500px; /* Set a fixed height for the table body */
    overflow-y: auto; /* Enable vertical scrolling for the table body */
}

#supplierTable thead th {
    position: sticky;
    top: 0;
    background-color: #f2f2f2;
    z-index: 2; /* Ensure the header is above the scrollable content */
}

#logoLink img {
        width: 250px; /* Adjust the width as needed */
        height: auto; /* Maintains the aspect ratio */
        margin-bottom: -10px; /* Adjust this value to fine-tune the alignment */
        margin-left: -52px;
    }

    </style>
</head>
<body>
    
                <div class="loader-container" id="loaderContainer">
        <div class="loader">
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
    <div class="circle"></div>
</div>

    </div>
    
<div class="navigation">
    <a href="index.php" id="logoLink">
        <img src="images/saebs_logo.png" alt="Logo">
    </a>
    <a href="index.php"><i class="material-icons">home</i> Home</a>
    <a href="inventory.php"><i class="material-icons">inbox</i> Inventory</a>
    <a href="notification.php"><i class="material-icons">history</i>Notification</a>
    <a href="pos.php"><i class="material-icons">attach_money</i> Point of Sale</a>
    <a href="sales_report.php"><i class="material-icons">insert_chart_outlined</i> Sales Report</a>
    <a href="transaction_history.php"><i class="material-icons">history</i> Transaction History</a>
            <a href="refund.php"><i class="material-icons">history</i> Refund</a>


    <?php
    if ($_SESSION['user_role'] === 'admin') {
        echo '<a href="employee_list.php"><i class="material-icons">people</i> Employee List</a>';
        echo '<a href="restock.php"><i class="material-icons">shopping_cart</i> Restock</a>';
        echo '<a href="supplier.php"><i class="material-icons">local_shipping</i> Supplier</a>';
        echo '<a href="view_sessions.php"><i class="material-icons">access_time</i> Sessions</a>';
    } elseif ($_SESSION['user_role'] === 'employee') {
        // Employee can only access limited features
    } else {
        echo "Invalid user role.";
    }
    ?>
    <a href="restock_history.php"><i class="material-icons">history</i> Restock History</a>
    <a href="logout.php" id="logoutLink"><i class="material-icons">exit_to_app</i> Logout</a>

    <?php
    // Check if the user has a custom image, otherwise, display a default image
    $userImage = isset($userData["user_image"]) ? $userData["user_image"] : "path/to/default-image.png";
    ?>
    <a href="user_info.php" class="user-info">
        <img src="<?php echo $userImage; ?>" alt="User Image">
    </a>
</div>

<div class="content">
    <h2>Supplier Information</h2>
    <div style="display: flex; align-items: center;">
    <input type="text" id="searchBox" placeholder="Search items">
     <button class="button" id="showFormButton">
  <svg viewBox="0 0 448 512" class="svgIcon">
    <path d="M224 48h-32v160H48v32h144v144h32V240h144v-32H224z"></path>
</svg>

</button>
</div>
<div class="table-wrapper">
    <table id="supplierTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Supplier Name</th>
                <th>Email Address</th>
                <th>Contact No</th>
            </tr>
        </thead>
        <tbody id="supplierData"></tbody>
    </table>
    </div>

    
        

   <!-- Modal -->
<div id="supplierModal" class="modal" style="display: none;">
    <div class="modal-content">
        <span id="closeModal" class="close">&times;</span>
        <h2 class="title">Add Supplier</h2>
        <!-- Supplier Insert Form -->
        <form id="supplierForm" action="insert_supplier.php" method="post" class="form">
            <label for="supplierName">
                <input type="text" id="supplierName" name="supplier_name" class="input" required>
                <span>Supplier Name</span>
            </label>

            <label for="emailAddress">
                <input type="email" id="emailAddress" name="email_address" class="input" required>
                <span>Email Address</span>
            </label>

            <label for="contactNo">
                <input type="text" id="contactNo" name="contact_no" class="input" required>
                <span>Contact No</span>
            </label>

            <input type="submit" value="Add Supplier" class="submit">
        </form>
    </div>
</div>

<!-- Add the following script just before the closing </body> tag -->
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Show loader on form submission
        document.getElementById('loaderContainer').style.display = 'flex';

        // Redirect to login.php after a delay (adjust as needed)
        setTimeout(function () {
           document.getElementById('loaderContainer').style.display = 'none';
        }, 1000); // Redirect after 1 second (1000 milliseconds)
    });
</script>

<script>
    // Function to fetch and display supplier data
    function fetchSuppliers() {
        const search = document.getElementById("searchBox").value;
        const supplierData = document.getElementById("supplierData");

        // Send an AJAX request to fetch_supplier.php
        const xhr = new XMLHttpRequest();
        xhr.open("GET", `fetch_supplier.php?search=${search}`);
        xhr.send();

        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                const response = JSON.parse(xhr.responseText);

                // Clear the supplier data
                supplierData.innerHTML = '';

                // Loop through the data and populate the table
                response.forEach(item => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${item.id}</td>
                        <td>${item.supplier_name}</td>
                        <td>${item.email_address}</td>
                        <td>${item.contact_no}</td>
      
                    `;
                    supplierData.appendChild(row);
                });
            }
        };
    }

    // Fetch supplier data on page load
    fetchSuppliers();

    // Add an event listener to the search input
    const searchBox = document.getElementById("searchBox");
    searchBox.addEventListener("input", fetchSuppliers);
    
    const showFormButton = document.getElementById("showFormButton");
    const closeModal = document.getElementById("closeModal");
    const supplierModal = document.getElementById("supplierModal");

    showFormButton.addEventListener("click", function() {
        supplierModal.style.display = "block";
    });

    closeModal.addEventListener("click", function() {
        supplierModal.style.display = "none";
    });
    
</script>
</body>
</html>
